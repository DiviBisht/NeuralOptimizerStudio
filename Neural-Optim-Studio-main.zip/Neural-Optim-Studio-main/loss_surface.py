

import numpy as np
from typing import Tuple
from tensorflow import keras



class LossSurface:
    
    def __init__(self, name: str, bounds: Tuple[float, float], description: str):
        self.name = name
        self.bounds = bounds
        self.description = description
    
    def compute(self, x: np.ndarray, y: np.ndarray) -> np.ndarray:
       
        raise NotImplementedError
    
    def gradient(self, x: float, y: float) -> Tuple[float, float]:
        
        raise NotImplementedError


class QuadraticBowl(LossSurface):
    """Simple quadratic: f(x,y) = x^2 + y^2"""
    def __init__(self):
        super().__init__("Quadratic Bowl", (-5, 5), "Simple quadratic surface. Optimal point: (0, 0)")
    
    def compute(self, x: np.ndarray, y: np.ndarray) -> np.ndarray:
        return x**2 + y**2
    
    def gradient(self, x: float, y: float) -> Tuple[float, float]:
        return 2*x, 2*y


class EllipsoidBowl(LossSurface):
    """Ellipsoid: f(x,y) = (x/5)^2 + (y/1)^2"""
    def __init__(self):
        super().__init__("Ellipsoid Bowl", (-10, 10), "Elongated valley. Challenges momentum methods.")
    
    def compute(self, x: np.ndarray, y: np.ndarray) -> np.ndarray:
        return (x/5)**2 + y**2
    
    def gradient(self, x: float, y: float) -> Tuple[float, float]:
        return 2*x/25, 2*y


class RosenbockSurface(LossSurface):
    """Rosenbrock: f(x,y) = (1-x)^2 + 100*(y-x^2)^2"""
    def __init__(self):
        super().__init__("Rosenbrock", (-2, 3), "Narrow valley. Optimal: (1, 1). Tests local minima navigation.")
    
    def compute(self, x: np.ndarray, y: np.ndarray) -> np.ndarray:
        return (1 - x)**2 + 100 * (y - x**2)**2
    
    def gradient(self, x: float, y: float) -> Tuple[float, float]:
        dx = -2*(1-x) - 400*x*(y-x**2)
        dy = 200*(y - x**2)
        return dx, dy


class RastriginSurface(LossSurface):
    """Rastrigin: f(x,y) = 20 + x^2 + y^2 - 10*cos(2π*x) - 10*cos(2π*y)"""
    def __init__(self):
        super().__init__("Rastrigin", (-5.12, 5.12), "Highly multimodal. Many local minima. Global min: (0,0)")
    
    def compute(self, x: np.ndarray, y: np.ndarray) -> np.ndarray:
        return 20 + x**2 + y**2 - 10*np.cos(2*np.pi*x) - 10*np.cos(2*np.pi*y)
    
    def gradient(self, x: float, y: float) -> Tuple[float, float]:
        dx = 2*x + 20*np.pi*np.sin(2*np.pi*x)
        dy = 2*y + 20*np.pi*np.sin(2*np.pi*y)
        return dx, dy


class BealeFunction(LossSurface):
    """Beale: f(x,y) = (1.5-x+xy)^2 + (2.25-x+xy^2)^2 + (2.625-x+xy^3)^2"""
    def __init__(self):
        super().__init__("Beale Function", (-4.5, 4.5), "Steep ridges and valleys. Optimal: (3, 0.5)")
    
    def compute(self, x: np.ndarray, y: np.ndarray) -> np.ndarray:
        return (1.5 - x + x*y)**2 + (2.25 - x + x*y**2)**2 + (2.625 - x + x*y**3)**2
    
    def gradient(self, x: float, y: float) -> Tuple[float, float]:
        t1 = 1.5 - x + x*y
        t2 = 2.25 - x + x*y**2
        t3 = 2.625 - x + x*y**3
        dx = 2*t1*(-1+y) + 2*t2*(-1+y**2) + 2*t3*(-1+y**3)
        dy = 2*t1*(x) + 2*t2*(2*x*y) + 2*t3*(3*x*y**2)
        return dx, dy


class AckleySurface(LossSurface):
    """Ackley: f(x,y) = -20*exp(-0.2*sqrt(0.5*(x^2+y^2))) - exp(0.5*(cos(2π*x)+cos(2π*y))) + e + 20"""
    def __init__(self):
        super().__init__("Ackley Function", (-5, 5), "Many local minima with steep walls. Tests exploration.")
    
    def compute(self, x: np.ndarray, y: np.ndarray) -> np.ndarray:
        r = np.sqrt(0.5*(x**2 + y**2))
        return -20*np.exp(-0.2*r) - np.exp(0.5*(np.cos(2*np.pi*x) + np.cos(2*np.pi*y))) + np.e + 20
    
    def gradient(self, x: float, y: float) -> Tuple[float, float]:
        r = np.sqrt(0.5*(x**2 + y**2))
        if r < 1e-10:
            return 0, 0
        c1 = np.cos(2*np.pi*x)
        c2 = np.cos(2*np.pi*y)
        e1 = np.exp(-0.2*r)
        e2 = np.exp(0.5*(c1 + c2))
        dx = 4*e1*x/r + np.pi*np.sin(2*np.pi*x)*e2
        dy = 4*e1*y/r + np.pi*np.sin(2*np.pi*y)*e2
        return dx, dy


class NoisyQuadratic(LossSurface):
    """Quadratic with noise: f(x,y) = x^2 + y^2 + noise*random"""
    def __init__(self, noise_level: float = 0.1):
        super().__init__("Noisy Quadratic", (-5, 5), f"Quadratic with {noise_level} noise (mini-batch effect)")
        self.noise_level = noise_level
    
    def compute(self, x: np.ndarray, y: np.ndarray) -> np.ndarray:
        base = x**2 + y**2
        np.random.seed(hash((str(x), str(y))) % (2**32))
        return base + self.noise_level * np.random.randn(*base.shape)
    
    def gradient(self, x: float, y: float) -> Tuple[float, float]:
        np.random.seed(hash((x, y)) % (2**32))
        return 2*x + self.noise_level * np.random.randn(), 2*y + self.noise_level * np.random.randn()


class CustomFunctionSurface(LossSurface):
    """User-defined loss function"""
    def __init__(self, func_string: str, bounds: Tuple[float, float] = (-5, 5)):
        self.func_string = func_string
        super().__init__("Custom Function", bounds, f"User-defined: {func_string[:50]}")
    
    def compute(self, x: np.ndarray, y: np.ndarray) -> np.ndarray:
        try:
            return eval(self.func_string, {"x": x, "y": y, "np": np})
        except:
            return np.zeros_like(x)
    
    def gradient(self, x: float, y: float, eps: float = 1e-5) -> Tuple[float, float]:
        f = lambda a, b: float(eval(self.func_string, {"x": a, "y": b, "np": np}))
        dx = (f(x + eps, y) - f(x - eps, y)) / (2 * eps)
        dy = (f(x, y + eps) - f(x, y - eps)) / (2 * eps)
        return dx, dy


class MNISTLossSurface(LossSurface):
    
    def __init__(self):
        super().__init__("MNIST Loss Surface", (-3, 3), "Real neural network loss on MNIST")
        self.model = None
        self.x_data = None
        self.y_data = None
        self._load_data()
    
    def _load_data(self):
        try:
            (x_train, y_train), _ = keras.datasets.mnist.load_data()
            x_train = x_train[:1000].reshape(-1, 28*28) / 255.0
            y_train = y_train[:1000]
            self.x_data = x_train
            self.y_data = keras.utils.to_categorical(y_train, 10)
        except:
            pass
    
    def compute(self, x: np.ndarray, y: np.ndarray) -> np.ndarray:
        if self.x_data is None:
            return np.ones_like(x) * 2.3
        result = np.zeros_like(x, dtype=float)
        for i in range(x.shape[0]):
            for j in range(x.shape[1]):
                w1 = np.random.RandomState(hash((x[i,j], y[i,j])) % 2**32).randn(784, 10) * np.abs(x[i,j])
                w2 = np.random.RandomState(hash((x[i,j]+1, y[i,j]+1)) % 2**32).randn(10, 10) * np.abs(y[i,j])
                logits = self.x_data @ w1 @ w2
                result[i, j] = -np.mean(self.y_data * np.log(np.exp(logits) / np.sum(np.exp(logits), axis=1, keepdims=True) + 1e-7))
        return result
    
    def gradient(self, x: float, y: float, eps: float = 1e-4) -> Tuple[float, float]:
        f = lambda a, b: self.compute(np.array([[a]]), np.array([[b]]))[0, 0]
        dx = (f(x + eps, y) - f(x - eps, y)) / (2 * eps)
        dy = (f(x, y + eps) - f(x, y - eps)) / (2 * eps)
        return dx, dy




def get_all_surfaces():
    
    return {
        "Quadratic Bowl": QuadraticBowl(),
        "Ellipsoid Bowl": EllipsoidBowl(),
        "Rosenbrock": RosenbockSurface(),
        "Rastrigin": RastriginSurface(),
        "Beale": BealeFunction(),
        "Ackley": AckleySurface(),
        "Noisy Quadratic": NoisyQuadratic(0.1),
        "MNIST Loss": MNISTLossSurface()
    }