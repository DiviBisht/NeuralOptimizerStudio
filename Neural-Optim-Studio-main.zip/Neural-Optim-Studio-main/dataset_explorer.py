"""
dataset_explorer.py
───────────────────
Upload any CSV/Excel dataset, pick feature + target columns, fit a simple
linear or logistic regression model with gradient descent, and watch how
each optimizer navigates the loss surface in real time.

Integrates with the existing Neural Optimizer Studio (main_app.py).
"""

import io
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
from matplotlib.colors import LinearSegmentedColormap
import streamlit as st

from optimizers import (
    SGD, Momentum, Nesterov, AdaGrad, RMSProp,
    Adam, AdamW, RAdam, LAMB, create_optimizer,
)

# ─────────────────────────────────────────────────────────────────────────────
# COLOUR PALETTE (matches the dark studio theme)
# ─────────────────────────────────────────────────────────────────────────────
ACCENT   = "#6C63FF"
ACCENT2  = "#4ECDC4"
ACCENT3  = "#FF6B6B"
GOLD     = "#FFD700"
BG_DARK  = "#0a0e1a"
BG_CARD  = "#111827"
BG_MID   = "#1a2235"
TEXT_DIM = "#94a3b8"

OPT_COLORS = {
    "SGD":        "#FF6B6B",
    "Momentum":   "#FFA500",
    "Nesterov":   "#FFD700",
    "AdaGrad":    "#4ECDC4",
    "RMSProp":    "#00CED1",
    "Adam":       "#6C63FF",
    "AdamW":      "#9B59B6",
    "RAdam":      "#2ECC71",
    "LAMB":       "#E91E63",
}

# ─────────────────────────────────────────────────────────────────────────────
# HELPER: normalise array to [0, 1]
# ─────────────────────────────────────────────────────────────────────────────

def _norm(arr: np.ndarray) -> np.ndarray:
    lo, hi = arr.min(), arr.max()
    if hi - lo < 1e-12:
        return np.zeros_like(arr, dtype=float)
    return (arr - lo) / (hi - lo)


# ─────────────────────────────────────────────────────────────────────────────
# DATASET LOSS SURFACES
# ─────────────────────────────────────────────────────────────────────────────

class LinearRegressionSurface:
    """
    MSE loss for single-feature linear regression  w0 + w1·x → y
    We optimise over (w0, w1) so this is a true 2-D surface.
    """

    def __init__(self, X: np.ndarray, y: np.ndarray):
        self.X = X.astype(float)          # shape (n,)
        self.y = y.astype(float)          # shape (n,)
        self.name = "Linear Regression (MSE)"
        # Analytical minimum
        Xm = np.stack([np.ones_like(X), X], axis=1)
        try:
            self.optimal = np.linalg.lstsq(Xm, y, rcond=None)[0]
        except Exception:
            self.optimal = np.array([0.0, 0.0])

    def compute(self, w0: np.ndarray, w1: np.ndarray) -> np.ndarray:
        """Vectorised MSE over a grid of (w0, w1) values."""
        # w0, w1 shape (H, W);  X shape (n,)
        preds = w0[..., np.newaxis] + w1[..., np.newaxis] * self.X   # (H, W, n)
        residuals = preds - self.y                                    # (H, W, n)
        return np.mean(residuals ** 2, axis=-1)

    def gradient(self, w0: float, w1: float) -> tuple:
        preds = w0 + w1 * self.X
        residuals = preds - self.y
        n = len(self.X)
        dw0 = 2 * np.mean(residuals)
        dw1 = 2 * np.mean(residuals * self.X)
        return float(dw0), float(dw1)

    def loss_scalar(self, w0: float, w1: float) -> float:
        preds = w0 + w1 * self.X
        return float(np.mean((preds - self.y) ** 2))


class LogisticRegressionSurface:
    """
    Binary cross-entropy loss  optimising (w0, w1).
    """

    def __init__(self, X: np.ndarray, y: np.ndarray):
        self.X = X.astype(float)
        self.y = y.astype(float)
        self.name = "Logistic Regression (BCE)"

    @staticmethod
    def _sigmoid(z):
        return 1.0 / (1.0 + np.exp(-np.clip(z, -500, 500)))

    def compute(self, w0: np.ndarray, w1: np.ndarray) -> np.ndarray:
        eps = 1e-12
        out = np.zeros_like(w0, dtype=float)
        for i in range(w0.shape[0]):
            for j in range(w0.shape[1]):
                z = w0[i, j] + w1[i, j] * self.X
                p = self._sigmoid(z)
                out[i, j] = -np.mean(
                    self.y * np.log(p + eps) + (1 - self.y) * np.log(1 - p + eps)
                )
        return out

    def gradient(self, w0: float, w1: float) -> tuple:
        z = w0 + w1 * self.X
        p = self._sigmoid(z)
        err = p - self.y
        dw0 = float(np.mean(err))
        dw1 = float(np.mean(err * self.X))
        return dw0, dw1

    def loss_scalar(self, w0: float, w1: float) -> float:
        eps = 1e-12
        z = w0 + w1 * self.X
        p = self._sigmoid(z)
        return float(-np.mean(self.y * np.log(p + eps) + (1 - self.y) * np.log(1 - p + eps)))


# ─────────────────────────────────────────────────────────────────────────────
# GRADIENT-DESCENT RUNNER
# ─────────────────────────────────────────────────────────────────────────────

def run_gradient_descent(surface, optimizer, w0_init: float, w1_init: float,
                         n_steps: int = 200) -> dict:
    """Run one optimizer on a surface and collect trajectory + losses."""
    state = optimizer.init_state(np.array([w0_init, w1_init]))

    for _ in range(n_steps):
        w0, w1 = state.params
        if np.isnan(w0) or np.isnan(w1) or np.abs(w0) > 1e6 or np.abs(w1) > 1e6:
            break
        loss = surface.loss_scalar(w0, w1)
        gx, gy = surface.gradient(w0, w1)
        # gradient clipping
        gnorm = np.sqrt(gx**2 + gy**2) + 1e-8
        if gnorm > 20.0:
            gx, gy = gx / gnorm * 20.0, gy / gnorm * 20.0
        optimizer.step(state, (gx, gy), loss)

    traj = np.array(state.trajectory)
    losses = np.array(state.loss_history[1:]) if len(state.loss_history) > 1 \
             else np.array(state.loss_history)
    return {"trajectory": traj, "losses": losses, "final_params": state.params.copy()}


# ─────────────────────────────────────────────────────────────────────────────
# MATPLOTLIB PLOTTING HELPERS
# ─────────────────────────────────────────────────────────────────────────────

def _dark_fig(*args, **kwargs):
    fig = plt.figure(*args, **kwargs)
    fig.patch.set_facecolor(BG_CARD)
    return fig


def _style_ax(ax, title="", xlabel="", ylabel=""):
    ax.set_facecolor(BG_MID)
    ax.tick_params(colors=TEXT_DIM, labelsize=8)
    for spine in ax.spines.values():
        spine.set_edgecolor("#2d3748")
    if title:
        ax.set_title(title, color="#e2e8f0", fontsize=9, fontweight="600", pad=8)
    if xlabel:
        ax.set_xlabel(xlabel, color=TEXT_DIM, fontsize=8)
    if ylabel:
        ax.set_ylabel(ylabel, color=TEXT_DIM, fontsize=8)
    ax.grid(True, color="#1e293b", linewidth=0.6, alpha=0.8)


def plot_loss_surface_with_trajectories(surface, results: dict,
                                        w0_range, w1_range,
                                        task_type: str) -> plt.Figure:
    """Contour plot of the loss surface with optimizer trajectories overlaid."""
    res = 80
    W0 = np.linspace(*w0_range, res)
    W1 = np.linspace(*w1_range, res)
    W0g, W1g = np.meshgrid(W0, W1)

    with st.spinner("Computing loss surface…"):
        if task_type == "Linear Regression":
            Z = surface.compute(W0g, W1g)
        else:
            # Logistic: compute row-by-row for speed
            Z = np.zeros_like(W0g)
            for i in range(res):
                for j in range(res):
                    Z[i, j] = surface.loss_scalar(W0g[i, j], W1g[i, j])

    fig, ax = plt.subplots(figsize=(8, 6))
    fig.patch.set_facecolor(BG_CARD)
    ax.set_facecolor(BG_MID)

    # Custom colormap
    cmap = LinearSegmentedColormap.from_list(
        "studio", ["#0a0e1a", "#1a1040", "#4f46e5", "#a78bfa", "#fde68a", "#fca5a5"])
    levels = np.linspace(Z.min(), np.percentile(Z, 95), 40)
    cf = ax.contourf(W0g, W1g, Z, levels=levels, cmap=cmap, alpha=0.85)
    cb = fig.colorbar(cf, ax=ax, shrink=0.85)
    cb.ax.yaxis.set_tick_params(color=TEXT_DIM, labelsize=7)
    plt.setp(cb.ax.yaxis.get_ticklabels(), color=TEXT_DIM)

    ax.contour(W0g, W1g, Z, levels=levels[::4], colors="white", alpha=0.12, linewidths=0.5)

    # Trajectories
    for opt_name, res_data in results.items():
        traj = res_data["trajectory"]
        if len(traj) < 2:
            continue
        color = OPT_COLORS.get(opt_name, "#ffffff")
        ax.plot(traj[:, 0], traj[:, 1], color=color, linewidth=1.5,
                alpha=0.85, label=opt_name, zorder=4)
        ax.scatter(traj[0, 0],  traj[0, 1],  color=color, marker="o",
                   s=60, zorder=5, edgecolors="white", linewidths=0.8)
        ax.scatter(traj[-1, 0], traj[-1, 1], color=color, marker="*",
                   s=120, zorder=5, edgecolors="white", linewidths=0.8)

    # Analytical optimum for linear regression
    if task_type == "Linear Regression" and hasattr(surface, "optimal"):
        ax.scatter(*surface.optimal, color=GOLD, marker="X", s=180,
                   zorder=6, edgecolors="black", linewidths=1, label="Optimal")

    ax.set_xlabel("w₀  (intercept)", color=TEXT_DIM, fontsize=8)
    ax.set_ylabel("w₁  (slope)",     color=TEXT_DIM, fontsize=8)
    ax.set_title("Loss Surface + Gradient Trajectories", color="#e2e8f0",
                 fontsize=10, fontweight="600", pad=10)
    ax.tick_params(colors=TEXT_DIM, labelsize=7)
    for sp in ax.spines.values():
        sp.set_edgecolor("#2d3748")

    legend = ax.legend(loc="upper right", fontsize=7, fancybox=True,
                       facecolor=BG_CARD, edgecolor="#2d3748", labelcolor="#e2e8f0")
    plt.tight_layout()
    return fig


def plot_convergence_curves(results: dict) -> plt.Figure:
    """Loss-vs-step curves for all selected optimizers."""
    fig, ax = plt.subplots(figsize=(8, 4))
    fig.patch.set_facecolor(BG_CARD)
    _style_ax(ax, "Convergence (Loss over Steps)", "Step", "Loss")

    for opt_name, res_data in results.items():
        losses = res_data["losses"]
        if len(losses) == 0:
            continue
        color = OPT_COLORS.get(opt_name, "#ffffff")
        ax.plot(losses, color=color, linewidth=1.8, label=opt_name, alpha=0.9)
        ax.scatter(len(losses) - 1, losses[-1], color=color, s=50, zorder=5)

    ax.legend(loc="upper right", fontsize=7, fancybox=True,
              facecolor=BG_CARD, edgecolor="#2d3748", labelcolor="#e2e8f0")
    plt.tight_layout()
    return fig


def plot_gradient_magnitude(results: dict, surface, n_steps: int) -> plt.Figure:
    """Gradient magnitude across steps for each optimizer."""
    fig, ax = plt.subplots(figsize=(8, 3.5))
    fig.patch.set_facecolor(BG_CARD)
    _style_ax(ax, "Gradient Magnitude over Steps", "Step", "‖∇L‖")

    for opt_name, res_data in results.items():
        traj = res_data["trajectory"]
        mags = []
        for pt in traj:
            gx, gy = surface.gradient(pt[0], pt[1])
            mags.append(np.sqrt(gx**2 + gy**2))
        color = OPT_COLORS.get(opt_name, "#ffffff")
        ax.plot(mags, color=color, linewidth=1.6, label=opt_name, alpha=0.9)

    ax.legend(loc="upper right", fontsize=7, fancybox=True,
              facecolor=BG_CARD, edgecolor="#2d3748", labelcolor="#e2e8f0")
    plt.tight_layout()
    return fig


def plot_dataset_overview(df: pd.DataFrame, x_col: str, y_col: str,
                          task_type: str) -> plt.Figure:
    """Scatter + distribution panels for the selected columns."""
    fig = _dark_fig(figsize=(10, 3.8))
    gs  = gridspec.GridSpec(1, 3, figure=fig, wspace=0.35)
    ax1 = fig.add_subplot(gs[0, :2])
    ax2 = fig.add_subplot(gs[0, 2])

    x_vals = df[x_col].values.astype(float)
    y_vals = df[y_col].values.astype(float)

    if task_type == "Logistic Regression":
        classes = np.unique(y_vals)
        pal = [ACCENT, ACCENT2, ACCENT3, GOLD]
        for idx, cls in enumerate(classes):
            mask = y_vals == cls
            ax1.scatter(x_vals[mask], y_vals[mask], color=pal[idx % len(pal)],
                        alpha=0.65, s=18, label=f"Class {int(cls)}")
        ax1.legend(fontsize=7, facecolor=BG_CARD, edgecolor="#2d3748", labelcolor="#e2e8f0")
    else:
        ax1.scatter(x_vals, y_vals, color=ACCENT, alpha=0.55, s=18)

    _style_ax(ax1, f"{x_col}  vs  {y_col}", x_col, y_col)

    ax2.hist(x_vals, bins=30, color=ACCENT, alpha=0.75, edgecolor="none")
    _style_ax(ax2, f"{x_col}  distribution", x_col, "Count")

    plt.suptitle("Dataset Overview", color="#e2e8f0", fontsize=10,
                 fontweight="600", y=1.02)
    return fig


def plot_fitted_line(df: pd.DataFrame, x_col: str, y_col: str,
                     results: dict, surface) -> plt.Figure:
    """Scatter + fitted lines from each optimizer's final weights."""
    fig, ax = plt.subplots(figsize=(8, 4.5))
    fig.patch.set_facecolor(BG_CARD)
    _style_ax(ax, "Dataset + Fitted Lines", x_col, y_col)

    x_vals = df[x_col].values.astype(float)
    y_vals = df[y_col].values.astype(float)
    ax.scatter(x_vals, y_vals, color="#4a5568", alpha=0.5, s=14, zorder=1, label="Data")

    x_line = np.linspace(x_vals.min(), x_vals.max(), 200)
    for opt_name, res_data in results.items():
        w0, w1 = res_data["final_params"]
        y_line = w0 + w1 * x_line
        color  = OPT_COLORS.get(opt_name, "#fff")
        ax.plot(x_line, y_line, color=color, linewidth=2, label=f"{opt_name} (w₀={w0:.3f}, w₁={w1:.3f})")

    if hasattr(surface, "optimal"):
        wo, w1o = surface.optimal
        ax.plot(x_line, wo + w1o * x_line, color=GOLD, linewidth=2,
                linestyle="--", label=f"OLS optimal", zorder=5)

    ax.legend(loc="upper left", fontsize=7, fancybox=True,
              facecolor=BG_CARD, edgecolor="#2d3748", labelcolor="#e2e8f0")
    plt.tight_layout()
    return fig


# ─────────────────────────────────────────────────────────────────────────────
# STREAMLIT CARD HELPERS
# ─────────────────────────────────────────────────────────────────────────────

def _card(title: str, body_html: str = ""):
    st.markdown(
        f'<div style="background:{BG_CARD};border:1px solid rgba(255,255,255,0.07);'
        f'border-radius:12px;padding:1.2rem 1.5rem;margin-bottom:.9rem;">'
        f'<div style="font-size:1rem;font-weight:600;color:#e2e8f0;margin-bottom:.5rem;">{title}</div>'
        f'{body_html}</div>',
        unsafe_allow_html=True,
    )


def _section(title: str):
    st.markdown(
        f'<div style="font-size:.85rem;font-weight:600;color:#a78bfa;letter-spacing:.06em;'
        f'text-transform:uppercase;border-bottom:1px solid rgba(167,139,250,.25);'
        f'padding-bottom:.35rem;margin:.5rem 0 .75rem;">{title}</div>',
        unsafe_allow_html=True,
    )


# ─────────────────────────────────────────────────────────────────────────────
# MAIN RENDER FUNCTION (called from main_app.py)
# ─────────────────────────────────────────────────────────────────────────────

def render_dataset_explorer():
    """
    Full Dataset Explorer tab — upload CSV/Excel, pick columns,
    run gradient descent, watch it work.
    """

    # ── Hero card ─────────────────────────────────────────────────────────────
    st.markdown("""
    <div style="background:linear-gradient(135deg,#1a1040 0%,#0f1e3d 60%,#0a0e1a 100%);
                border:1px solid rgba(108,99,255,0.30);border-radius:14px;
                padding:1.8rem 2.2rem 1.4rem;margin-bottom:1.4rem;position:relative;overflow:hidden;">
      <div style="position:absolute;top:-50px;right:-50px;width:220px;height:220px;
                  background:radial-gradient(circle,rgba(78,205,196,0.15) 0%,transparent 70%);
                  border-radius:50%;"></div>
      <div style="font-size:1.9rem;font-weight:700;
                  background:linear-gradient(90deg,#4ECDC4,#6C63FF,#a78bfa);
                  -webkit-background-clip:text;-webkit-text-fill-color:transparent;
                  margin-bottom:.35rem;">📂 Dataset Gradient Explorer</div>
      <div style="color:#94a3b8;font-size:.95rem;">
        Upload your own CSV or Excel file, select a feature and a target column,
        then watch multiple optimizers navigate the resulting loss surface in real time.
      </div>
    </div>
    """, unsafe_allow_html=True)

    # ── Upload ─────────────────────────────────────────────────────────────────
    _section("① Upload Dataset")
    uploaded_file = st.file_uploader(
        "CSV or Excel file",
        type=["csv", "xlsx", "xls"],
        help="Needs at least two numeric columns.",
    )

    if uploaded_file is None:
        st.markdown("""
        <div style="text-align:center;padding:3rem 2rem;color:#475569;">
          <div style="font-size:3.5rem;margin-bottom:.8rem;">📁</div>
          <div style="color:#64748b;font-size:.95rem;">
            Drop a CSV or Excel file above to get started.<br>
            <span style="font-size:.82rem;">Sample datasets: Boston Housing, Iris, any regression / binary-classification CSV.</span>
          </div>
        </div>
        """, unsafe_allow_html=True)
        return

    # ── Parse ──────────────────────────────────────────────────────────────────
    try:
        if uploaded_file.name.endswith((".xlsx", ".xls")):
            df = pd.read_excel(uploaded_file)
        else:
            df = pd.read_csv(uploaded_file)
    except Exception as e:
        st.error(f"❌ Could not read file: {e}")
        return

    df = df.dropna()
    numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()

    if len(numeric_cols) < 2:
        st.warning("⚠️ The file needs at least two numeric columns.")
        return

    st.success(f"✅  Loaded **{df.shape[0]:,} rows × {df.shape[1]} columns** — {len(numeric_cols)} numeric")

    with st.expander("🔍 Preview data", expanded=False):
        st.dataframe(df.head(50), use_container_width=True)

    # ── Column selection + task ────────────────────────────────────────────────
    _section("② Configure Task")
    col_a, col_b, col_c = st.columns(3)

    with col_a:
        feature_col = st.selectbox("Feature column (X)", numeric_cols, key="de_feat")
    with col_b:
        remaining = [c for c in numeric_cols if c != feature_col]
        target_col = st.selectbox("Target column (y)", remaining, key="de_tgt")
    with col_c:
        # Infer sensible default
        unique_y = df[target_col].nunique()
        default_task = "Logistic Regression" if unique_y <= 5 else "Linear Regression"
        task_type = st.selectbox(
            "Task type",
            ["Linear Regression", "Logistic Regression"],
            index=0 if default_task == "Linear Regression" else 1,
            key="de_task",
        )

    # Validate logistic target
    if task_type == "Logistic Regression":
        unique_vals = np.sort(df[target_col].unique())
        if len(unique_vals) != 2 or not set(unique_vals).issubset({0, 1, 0.0, 1.0}):
            st.warning(
                "⚠️  Logistic Regression expects a binary 0 / 1 target. "
                f"Found: {unique_vals[:6]}. Switching to Linear Regression."
            )
            task_type = "Linear Regression"

    # ── Normalise features ─────────────────────────────────────────────────────
    X_raw = df[feature_col].values.astype(float)
    y_raw = df[target_col].values.astype(float)
    X_norm = _norm(X_raw)

    # Build surface
    if task_type == "Linear Regression":
        surface = LinearRegressionSurface(X_norm, y_raw)
    else:
        surface = LogisticRegressionSurface(X_norm, y_raw)

    # ── Dataset overview plot ──────────────────────────────────────────────────
    _section("③ Dataset Overview")
    fig_overview = plot_dataset_overview(df, feature_col, target_col, task_type)
    st.pyplot(fig_overview, use_container_width=True)
    plt.close(fig_overview)

    # ── Optimizer config ───────────────────────────────────────────────────────
    _section("④ Optimizer Setup")
    left_cfg, right_cfg = st.columns([1, 1.6], gap="large")

    ALL_OPTS = ["SGD", "Momentum", "Nesterov", "AdaGrad", "RMSProp", "Adam", "AdamW", "RAdam", "LAMB"]

    with left_cfg:
        selected_opts = st.multiselect(
            "Select optimizers to compare",
            ALL_OPTS,
            default=["SGD", "Adam"],
            key="de_opts",
        )
        n_steps = st.slider("Gradient steps", 50, 500, 200, 25, key="de_steps")
        lr_val  = st.slider("Learning rate", 0.0001, 0.5, 0.05, 0.0005,
                            format="%.4f", key="de_lr")

    with right_cfg:
        st.markdown(f"""
        <div style="background:{BG_MID};border:1px solid rgba(255,255,255,.07);
                    border-radius:10px;padding:1rem 1.2rem;font-size:.88rem;color:#94a3b8;">
          <b style="color:#e2e8f0;">How it works</b><br><br>
          • Your dataset is reduced to a <b>1-feature</b> problem so the loss landscape
            lives in 2-D: <code>(w₀, w₁)</code> — intercept and slope.<br><br>
          • Each optimizer starts from the <b>same random initial weights</b> and takes
            <b>{n_steps} gradient steps</b> at learning rate <b>{lr_val}</b>.<br><br>
          • The contour plot shows the loss surface; trajectories show each optimizer's
            path toward the minimum. <span style="color:#FFD700;">★</span> marks the
            analytically optimal point (linear regression only).
        </div>
        """, unsafe_allow_html=True)

    # Starting weights
    st.markdown("")
    w0_init_col, w1_init_col = st.columns(2)
    with w0_init_col:
        w0_init = st.slider("Initial w₀ (intercept)", -3.0, 3.0, 2.0, 0.1, key="de_w0")
    with w1_init_col:
        w1_init = st.slider("Initial w₁ (slope)",     -3.0, 3.0, -2.0, 0.1, key="de_w1")

    # ── Run ────────────────────────────────────────────────────────────────────
    run_btn = st.button("🚀 Run Gradient Descent", type="primary",
                        use_container_width=True, key="de_run")

    if not run_btn:
        st.markdown("""
        <div style="text-align:center;padding:2rem;color:#475569;">
          <div style="font-size:2.5rem;margin-bottom:.6rem;">⚙️</div>
          <div style="color:#64748b;">Configure your optimizers and click <b>Run Gradient Descent</b></div>
        </div>
        """, unsafe_allow_html=True)
        return

    if not selected_opts:
        st.warning("Please select at least one optimizer.")
        return

    # ── Execute all optimizers ─────────────────────────────────────────────────
    results = {}
    progress = st.progress(0)
    for idx, opt_name in enumerate(selected_opts):
        opt = create_optimizer(opt_name, lr_val)
        results[opt_name] = run_gradient_descent(surface, opt, w0_init, w1_init, n_steps)
        progress.progress((idx + 1) / len(selected_opts))
    progress.empty()

    # ── Summary metrics ────────────────────────────────────────────────────────
    _section("⑤ Results")
    cols = st.columns(len(selected_opts))
    for col, (opt_name, res_data) in zip(cols, results.items()):
        final_loss = res_data["losses"][-1] if len(res_data["losses"]) > 0 else float("nan")
        w0f, w1f   = res_data["final_params"]
        color      = OPT_COLORS.get(opt_name, "#fff")
        col.markdown(
            f'<div style="background:{BG_MID};border:1px solid rgba(255,255,255,.07);'
            f'border-radius:10px;padding:.8rem 1rem;text-align:center;">'
            f'<div style="font-size:.75rem;color:{TEXT_DIM};text-transform:uppercase;'
            f'letter-spacing:.06em;margin-bottom:.3rem;">{opt_name}</div>'
            f'<div style="font-size:1.15rem;font-weight:700;color:{color};">{final_loss:.5f}</div>'
            f'<div style="font-size:.72rem;color:{TEXT_DIM};margin-top:.3rem;">'
            f'w₀={w0f:.4f} &nbsp;·&nbsp; w₁={w1f:.4f}</div>'
            f'</div>',
            unsafe_allow_html=True,
        )

    # ── Plots ──────────────────────────────────────────────────────────────────
    # Auto-detect w0/w1 range from trajectories
    all_traj = np.concatenate([r["trajectory"] for r in results.values()], axis=0)
    w0_min, w0_max = all_traj[:, 0].min(), all_traj[:, 0].max()
    w1_min, w1_max = all_traj[:, 1].min(), all_traj[:, 1].max()
    pad0 = max((w0_max - w0_min) * 0.4, 0.5)
    pad1 = max((w1_max - w1_min) * 0.4, 0.5)
    w0_range = (w0_min - pad0, w0_max + pad0)
    w1_range = (w1_min - pad1, w1_max + pad1)

    plot_tabs = st.tabs(["🗺 Loss Surface", "📉 Convergence", "📐 Gradient Magnitude",
                          "🔧 Fitted Lines"])

    with plot_tabs[0]:
        fig_surf = plot_loss_surface_with_trajectories(
            surface, results, w0_range, w1_range, task_type)
        st.pyplot(fig_surf, use_container_width=True)
        plt.close(fig_surf)

    with plot_tabs[1]:
        fig_conv = plot_convergence_curves(results)
        st.pyplot(fig_conv, use_container_width=True)
        plt.close(fig_conv)

    with plot_tabs[2]:
        fig_grad = plot_gradient_magnitude(results, surface, n_steps)
        st.pyplot(fig_grad, use_container_width=True)
        plt.close(fig_grad)

    with plot_tabs[3]:
        if task_type == "Linear Regression":
            fig_fit = plot_fitted_line(df, feature_col, target_col, results, surface)
            st.pyplot(fig_fit, use_container_width=True)
            plt.close(fig_fit)
        else:
            st.info("Fitted-line view is only available for Linear Regression.")

    # ── Winner ─────────────────────────────────────────────────────────────────
    if len(results) > 1:
        best_name = min(results, key=lambda k: (
            results[k]["losses"][-1] if len(results[k]["losses"]) > 0 else float("inf")))
        best_loss = results[best_name]["losses"][-1] if len(results[best_name]["losses"]) > 0 else float("nan")
        color = OPT_COLORS.get(best_name, GOLD)
        st.markdown(
            f'<div style="background:linear-gradient(135deg,rgba(108,99,255,.14),'
            f'rgba(78,205,196,.09));border:1px solid rgba(108,99,255,.35);'
            f'border-radius:12px;padding:1rem 1.4rem;margin-top:.6rem;">'
            f'<span style="font-size:1rem;font-weight:700;color:#e2e8f0;">🏆 Winner: '
            f'<span style="color:{color}">{best_name}</span></span>'
            f'<span style="color:#94a3b8;font-size:.88rem;"> — final loss '
            f'<b style="color:{ACCENT2}">{best_loss:.6f}</b></span></div>',
            unsafe_allow_html=True,
        )

    # ── Detailed step-by-step table ────────────────────────────────────────────
    with st.expander("📋 Step-by-step loss table", expanded=False):
        max_len = max(len(r["losses"]) for r in results.values())
        table   = {"Step": list(range(max_len))}
        for opt_name, res_data in results.items():
            losses = list(res_data["losses"])
            # Pad shorter runs with the last value
            padded = losses + [losses[-1]] * (max_len - len(losses)) if losses else [float("nan")] * max_len
            table[opt_name] = [f"{v:.6f}" for v in padded]
        st.dataframe(pd.DataFrame(table), use_container_width=True)

    # ── Gradient field viz ─────────────────────────────────────────────────────
    with st.expander("🧭 Gradient vector field", expanded=False):
        st.markdown(
            '<div style="color:#94a3b8;font-size:.85rem;margin-bottom:.6rem;">'
            "Arrows show the direction of steepest ascent — optimizers move <i>opposite</i> to these."
            "</div>",
            unsafe_allow_html=True,
        )
        grid_n = 18
        gw0 = np.linspace(*w0_range, grid_n)
        gw1 = np.linspace(*w1_range, grid_n)
        GW0, GW1 = np.meshgrid(gw0, gw1)
        U, V = np.zeros_like(GW0), np.zeros_like(GW1)
        for i in range(grid_n):
            for j in range(grid_n):
                u, v = surface.gradient(GW0[i, j], GW1[i, j])
                U[i, j], V[i, j] = u, v

        fig_vec, ax_v = plt.subplots(figsize=(7, 5))
        fig_vec.patch.set_facecolor(BG_CARD)
        _style_ax(ax_v, "Gradient Vector Field", "w₀  (intercept)", "w₁  (slope)")
        speed = np.sqrt(U**2 + V**2) + 1e-8
        ax_v.quiver(GW0, GW1, U / speed, V / speed, speed,
                    cmap="plasma", alpha=0.75, scale=30, width=0.003)
        for opt_name, res_data in results.items():
            traj = res_data["trajectory"]
            c = OPT_COLORS.get(opt_name, "#fff")
            ax_v.plot(traj[:, 0], traj[:, 1], color=c, linewidth=1.4, alpha=0.85, label=opt_name)
            ax_v.scatter(traj[-1, 0], traj[-1, 1], color=c, marker="*", s=100, zorder=5)
        ax_v.legend(loc="upper right", fontsize=7, facecolor=BG_CARD,
                    edgecolor="#2d3748", labelcolor="#e2e8f0")
        st.pyplot(fig_vec, use_container_width=True)
        plt.close(fig_vec)