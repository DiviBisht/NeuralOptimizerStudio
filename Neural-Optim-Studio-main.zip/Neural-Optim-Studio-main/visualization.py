import streamlit as st
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots
import pandas as pd
from matplotlib.ticker import ScalarFormatter

COLORS = ['#FF6B6B','#4ECDC4','#FFE66D','#A29BFE','#FD79A8','#74B9FF','#55EFC4','#FDCB6E','#E17055']
BG     = '#0a0e1a'
PANEL  = '#111827'
CARD   = '#1a2235'
ACCENT = '#6C63FF'

# ─────────────────────────────────────────────────────────────────────────────
# HELPERS
# ─────────────────────────────────────────────────────────────────────────────
def _prep(state):
    traj   = np.array(state.trajectory)
    losses = list(state.loss_history)
    if len(losses) < len(traj):
        pad    = [losses[0]] * (len(traj) - len(losses)) if losses else [0.0]*len(traj)
        losses = pad + losses
    grads = list(state.grad_history)
    return traj, np.array(losses[:len(traj)], dtype=float), grads


def _base_layout(title='', height=650):
    return dict(
        title=dict(text=title, x=0.5, xanchor='center',
                   font=dict(size=16, color='#e2e8f0', family='Inter, sans-serif')),
        paper_bgcolor=BG, plot_bgcolor=PANEL,
        height=height,
        font=dict(color='#94a3b8', family='Inter, sans-serif', size=12),
        legend=dict(bgcolor='rgba(17,24,39,0.85)', bordercolor='rgba(255,255,255,0.12)',
                    borderwidth=1, font=dict(size=12)),
        margin=dict(l=60, r=40, t=80, b=60),
        hovermode='closest',
    )


def _anim_menus(duration=90):
    return [dict(
        type='buttons', showactive=False,
        y=1.08, x=0.0, xanchor='left',
        bgcolor='rgba(108,99,255,0.2)', bordercolor=ACCENT,
        font=dict(color='white', size=13),
        buttons=[
            dict(label='▶  Play',  method='animate',
                 args=[None, dict(frame=dict(duration=duration, redraw=True),
                                  fromcurrent=True, mode='immediate',
                                  transition=dict(duration=0))]),
            dict(label='⏸ Pause', method='animate',
                 args=[[None], dict(frame=dict(duration=0, redraw=False), mode='immediate')])
        ]
    )]


def _slider(n_steps, prefix='Step'):
    steps = [dict(args=[[str(k)], dict(frame=dict(duration=90, redraw=True), mode='immediate')],
                  label=str(k), method='animate') for k in range(n_steps)]
    return [dict(active=0,
                 currentvalue=dict(prefix=f'{prefix}: ', font=dict(size=13, color='white'), xanchor='center'),
                 pad=dict(t=55, b=10),
                 steps=steps,
                 bgcolor='rgba(255,255,255,0.07)',
                 bordercolor='rgba(255,255,255,0.15)',
                 tickcolor='rgba(255,255,255,0.3)',
                 font=dict(color='#94a3b8'))]


# ─────────────────────────────────────────────────────────────────────────────
# 3-D LIVE ANIMATED SURFACE  (st.empty + time.sleep — real-time rolling balls)
# ─────────────────────────────────────────────────────────────────────────────
def plot_3d_surface(X, Y, Z, results, surface_name):
    """
    Renders the 3-D loss surface once, then streams optimizer ball positions
    into st.empty() step-by-step so the balls visibly roll down the surface.
    Speed, step-skip and camera angle are user-controlled.
    """
    import time

    if not results:
        st.warning("No results yet — run the optimisation first.")
        return

    Z_c = np.clip(Z, np.percentile(Z, 1), np.percentile(Z, 99))
    max_steps = max(len(s.trajectory) for s in results.values())

    # ── controls row ──────────────────────────────────────────────────────────
    ctl1, ctl2, ctl3, ctl4 = st.columns([1, 1, 1, 1])
    with ctl1:
        speed = st.select_slider(
            "Animation Speed",
            options=["0.25×", "0.5×", "1×", "2×", "4×"],
            value="1×", key="anim_speed_3d"
        )
    with ctl2:
        step_skip = st.slider("Frame Skip", 1, 10, 1, 1,
                              help="Show every Nth step (higher = faster but coarser)",
                              key="anim_skip_3d")
    with ctl3:
        camera_preset = st.selectbox("Camera Angle",
            ["Diagonal", "Top-Down", "Front", "Side"], key="cam_3d")
    with ctl4:
        show_trail = st.checkbox("Show Trail", value=True, key="trail_3d")

    run_col, _ = st.columns([1, 3])
    with run_col:
        play = st.button("▶  Play Animation", type="primary",
                         use_container_width=True, key="play_3d")

    speed_map  = {"0.25×": 0.40, "0.5×": 0.20, "1×": 0.10, "2×": 0.05, "4×": 0.02}
    delay      = speed_map[speed]

    camera_map = {
        "Diagonal":  dict(eye=dict(x=1.7,  y=-1.7, z=1.3)),
        "Top-Down":  dict(eye=dict(x=0.0,  y=0.0,  z=2.8)),
        "Front":     dict(eye=dict(x=0.0,  y=-2.5, z=0.8)),
        "Side":      dict(eye=dict(x=2.5,  y=0.0,  z=0.8)),
    }
    camera = camera_map[camera_preset]

    # ── static surface trace (built once) ────────────────────────────────────
    surface_trace = go.Surface(
        x=X[0, :], y=Y[:, 0], z=Z_c,
        opacity=0.70,
        colorscale='Plasma',
        showscale=True,
        colorbar=dict(
            title=dict(text='Loss', font=dict(color='#94a3b8', size=12)),
            tickfont=dict(color='#94a3b8'), thickness=14, len=0.75, x=1.01
        ),
        contours=dict(
            z=dict(show=True, usecolormap=True, highlightcolor='white',
                   project_z=True, width=1)
        ),
        hovertemplate='x=%{x:.3f}<br>y=%{y:.3f}<br>loss=%{z:.4f}<extra>Surface</extra>',
        name='Loss Surface',
        lighting=dict(ambient=0.6, diffuse=0.8, specular=0.3, roughness=0.5),
        lightposition=dict(x=1000, y=1000, z=1000),
    )

    # ── helper: build scatter traces for one step ─────────────────────────────
    def make_ball_traces(step):
        traces = []
        for idx, (name, state) in enumerate(results.items()):
            traj, z_vals, _ = _prep(state)
            col = COLORS[idx % len(COLORS)]
            end = min(step + 1, len(traj))
            zc  = np.clip(z_vals[:end], Z_c.min(), Z_c.max())

            # trail line
            if show_trail and end > 1:
                traces.append(go.Scatter3d(
                    x=traj[:end, 0], y=traj[:end, 1], z=zc,
                    mode='lines',
                    line=dict(width=5, color=col),
                    name=name,
                    showlegend=True,
                    legendgroup=name,
                    opacity=0.85,
                    hoverinfo='skip'
                ))

            # glowing ball at current position
            cx, cy, cz = float(traj[end-1, 0]), float(traj[end-1, 1]), float(zc[-1])
            traces.append(go.Scatter3d(
                x=[cx], y=[cy], z=[cz],
                mode='markers',
                marker=dict(
                    size=10,
                    color=col,
                    symbol='circle',
                    line=dict(width=2.5, color='white'),
                    opacity=1.0,
                ),
                name=name if not show_trail else f'{name} (pos)',
                showlegend=(not show_trail),
                legendgroup=name,
                hovertemplate=(
                    f'<b>{name}</b><br>'
                    f'Step: {end-1}<br>'
                    'x=%{x:.4f}<br>y=%{y:.4f}<br>'
                    f'loss={cz:.5f}<extra></extra>'
                )
            ))

            # start marker (only on first frame)
            if step == 0:
                traces.append(go.Scatter3d(
                    x=[float(traj[0, 0])], y=[float(traj[0, 1])], z=[float(zc[0])],
                    mode='markers',
                    marker=dict(symbol='square', size=7, color=col,
                                line=dict(width=1.5, color='white'), opacity=0.7),
                    showlegend=False, legendgroup=name, hoverinfo='skip'
                ))
        return traces

    # ── shared layout (built once, reused every frame) ────────────────────────
    # Build base then override/add keys — avoids duplicate keyword error
    base_layout = _base_layout(f'<b>3-D Live Optimizer Trajectories — {surface_name}</b>', height=720)
    base_layout.update(dict(
        scene=dict(
            xaxis=dict(title='X', backgroundcolor='#0d1117',
                       gridcolor='rgba(255,255,255,0.08)',
                       showbackground=True, tickfont=dict(color='#64748b')),
            yaxis=dict(title='Y', backgroundcolor='#0d1117',
                       gridcolor='rgba(255,255,255,0.08)',
                       showbackground=True, tickfont=dict(color='#64748b')),
            zaxis=dict(title='Loss', backgroundcolor='#0d1117',
                       gridcolor='rgba(255,255,255,0.08)',
                       showbackground=True, tickfont=dict(color='#64748b')),
            camera=camera,
            aspectmode='auto',
        ),
        showlegend=True,
        legend=dict(
            x=0.01, y=0.99,
            bgcolor='rgba(10,14,26,0.80)',
            bordercolor='rgba(255,255,255,0.15)',
            borderwidth=1,
            font=dict(size=12, color='#e2e8f0')
        ),
        margin=dict(l=0, r=30, t=80, b=0),
        uirevision='static',
    ))

    # ── placeholder for live updates ──────────────────────────────────────────
    placeholder = st.empty()

    # ── draw the initial (step-0) frame immediately ───────────────────────────
    init_fig = go.Figure(data=[surface_trace] + make_ball_traces(0))
    init_fig.update_layout(base_layout)
    placeholder.plotly_chart(init_fig, use_container_width=True, key="fig3d_init")

    # ── step counter below the chart ──────────────────────────────────────────
    step_info = st.empty()
    step_info.markdown(
        f'<div style="text-align:center;color:#64748b;font-size:.85rem;">'
        f'Showing step <b style="color:#a78bfa">0</b> / {max_steps-1} &nbsp;·&nbsp; '
        f'Press <b style="color:#a78bfa">▶ Play Animation</b> to start</div>',
        unsafe_allow_html=True
    )

    # ── loss mini-chart (updates alongside 3D) ────────────────────────────────
    loss_placeholder = st.empty()

    # ── animation loop — only runs when Play is pressed ───────────────────────
    if play:
        steps_to_show = list(range(0, max_steps, step_skip))
        if steps_to_show[-1] != max_steps - 1:
            steps_to_show.append(max_steps - 1)

        for step in steps_to_show:
            ball_traces = make_ball_traces(step)
            fig = go.Figure(data=[surface_trace] + ball_traces)
            fig.update_layout(base_layout)
            placeholder.plotly_chart(fig, use_container_width=True, key=f"fig3d_{step}")

            # live loss mini-chart
            loss_fig = go.Figure()
            for idx, (name, state) in enumerate(results.items()):
                _, z_vals, _ = _prep(state)
                col = COLORS[idx % len(COLORS)]
                end = min(step + 1, len(z_vals))
                loss_fig.add_trace(go.Scatter(
                    x=list(range(end)), y=z_vals[:end].tolist(),
                    mode='lines', name=name,
                    line=dict(color=col, width=2.2)
                ))
            _ll = _base_layout('Loss Convergence (live)', height=220)
            _ll.update(dict(
                xaxis=dict(title='Step', gridcolor='rgba(255,255,255,0.06)', range=[0, max_steps]),
                yaxis=dict(title='Loss', type='log', gridcolor='rgba(255,255,255,0.06)'),
                showlegend=True,
                margin=dict(l=50, r=20, t=50, b=40),
            ))
            loss_fig.update_layout(_ll)
            loss_placeholder.plotly_chart(loss_fig, use_container_width=True,
                                          key=f"loss_{step}")

            # step counter
            pct = int(100 * step / max(max_steps-1, 1))
            step_info.markdown(
                f'<div style="text-align:center;color:#64748b;font-size:.85rem;">'
                f'Step <b style="color:#a78bfa">{step}</b> / {max_steps-1} &nbsp;·&nbsp; '
                f'<span style="color:#4ECDC4">{pct}% complete</span></div>',
                unsafe_allow_html=True
            )
            time.sleep(delay)

        # final frame — show complete trajectories
        step_info.markdown(
            f'<div style="text-align:center;color:#64748b;font-size:.85rem;">'
            f'✅ Animation complete — '
            + " &nbsp;|&nbsp; ".join(
                f'<span style="color:{COLORS[i%len(COLORS)]}">{n}: '
                f'{min(s.loss_history):.5f}</span>'
                for i,(n,s) in enumerate(results.items())
            )
            + '</div>',
            unsafe_allow_html=True
        )


# ─────────────────────────────────────────────────────────────────────────────
# CONTOUR PLOT  (Plotly, not matplotlib)
# ─────────────────────────────────────────────────────────────────────────────
def plot_contour_with_trajectories(X, Y, Z, results, surface, surface_name):
    Z_c = np.clip(Z, np.percentile(Z,2), np.percentile(Z,98))

    # gradient field
    skip = max(1, X.shape[0]//16)
    Xf, Yf = X[::skip,::skip].flatten(), Y[::skip,::skip].flatten()
    arrow = (X[0,-1]-X[0,0])*0.055
    gx_a, gy_a = [], []
    for xi,yi in zip(Xf,Yf):
        gx,gy = surface.gradient(float(xi), float(yi))
        n = np.sqrt(gx**2+gy**2)+1e-8
        gx_a.append(-gx/n*arrow); gy_a.append(-gy/n*arrow)

    sx,sy=[],[]
    for xi,yi,dxi,dyi in zip(Xf,Yf,gx_a,gy_a):
        sx+=[xi,xi+dxi,None]; sy+=[yi,yi+dyi,None]

    fig = go.Figure()
    fig.add_trace(go.Contour(
        x=X[0,:], y=Y[:,0], z=Z_c, colorscale='Viridis',
        contours=dict(showlabels=True, labelfont=dict(size=8,color='white')),
        line=dict(width=0.6), opacity=0.88, showscale=True,
        colorbar=dict(title=dict(text='Loss',font=dict(color='#94a3b8')),
                      tickfont=dict(color='#94a3b8'),thickness=12,len=0.8,x=1.01),
        hovertemplate='x=%{x:.3f}<br>y=%{y:.3f}<br>loss=%{z:.4f}<extra></extra>'
    ))
    fig.add_trace(go.Scatter(x=sx,y=sy,mode='lines',
        line=dict(color='rgba(200,200,200,0.22)',width=1),hoverinfo='skip',showlegend=False))
    fig.add_trace(go.Scatter(
        x=[xi+dxi for xi,dxi in zip(Xf,gx_a)],
        y=[yi+dyi for yi,dyi in zip(Yf,gy_a)],
        mode='markers',
        marker=dict(symbol='triangle-right',size=4,color='rgba(200,200,200,0.40)',
                    angle=[float(np.degrees(np.arctan2(dy,dx))) for dx,dy in zip(gx_a,gy_a)]),
        hoverinfo='skip', showlegend=False
    ))

    for idx,(name,state) in enumerate(results.items()):
        traj,_,_ = _prep(state)
        col = COLORS[idx%len(COLORS)]
        fig.add_trace(go.Scatter(
            x=traj[:,0], y=traj[:,1], mode='lines+markers', name=name,
            line=dict(color=col,width=2.5),
            marker=dict(size=4,color=col,opacity=0.6,line=dict(width=0.5,color='white')),
            hovertemplate=f'<b>{name}</b><br>x=%{{x:.4f}}<br>y=%{{y:.4f}}<extra></extra>'
        ))
        fig.add_trace(go.Scatter(
            x=[traj[0,0]],y=[traj[0,1]],mode='markers',
            marker=dict(symbol='square',size=10,color=col,line=dict(width=2,color='white')),
            showlegend=False, legendgroup=name,
            hovertemplate=f'<b>{name} START</b><extra></extra>'
        ))
        fig.add_trace(go.Scatter(
            x=[traj[-1,0]],y=[traj[-1,1]],mode='markers',
            marker=dict(symbol='star',size=14,color=col,line=dict(width=2,color='white')),
            showlegend=False, legendgroup=name,
            hovertemplate=f'<b>{name} END</b><extra></extra>'
        ))

    # global minimum marker — use unclipped Z for accurate detection
    _Z_full    = surface.compute(X, Y)
    _min_idx   = np.unravel_index(np.argmin(_Z_full), _Z_full.shape)
    _gmin_x    = float(X[_min_idx])
    _gmin_y    = float(Y[_min_idx])
    _gmin_loss = float(_Z_full[_min_idx])
    fig.add_trace(go.Scatter(
        x=[_gmin_x], y=[_gmin_y], mode='markers+text',
        marker=dict(symbol='star', size=22, color='#FFD700',
                    line=dict(color='white', width=2)),
        text=['Global Min'], textposition='top center',
        textfont=dict(color='#FFD700', size=10),
        name='🎯 Global Minimum', showlegend=True,
        hovertemplate=(f'<b>🎯 Global Minimum</b><br>'
                       f'x={_gmin_x:.4f}<br>y={_gmin_y:.4f}<br>'
                       f'loss={_gmin_loss:.5f}<extra></extra>')
    ))
    # outer ring
    fig.add_trace(go.Scatter(
        x=[_gmin_x], y=[_gmin_y], mode='markers',
        marker=dict(symbol='circle', size=32, color='rgba(0,0,0,0)',
                    line=dict(color='rgba(255,215,0,0.45)', width=2.5)),
        showlegend=False, hoverinfo='skip'
    ))

    layout = _base_layout(f'<b>Contour + Gradient Field — {surface_name}</b>', height=640)
    layout.update(
        xaxis=dict(title='X', showgrid=True, gridcolor='rgba(255,255,255,0.06)', zeroline=False),
        yaxis=dict(title='Y', showgrid=True, gridcolor='rgba(255,255,255,0.06)', zeroline=False,
                   scaleanchor='x'),
    )
    fig.update_layout(layout)
    st.plotly_chart(fig, use_container_width=True)


# ─────────────────────────────────────────────────────────────────────────────
# REAL-TIME ANIMATED GRADIENT  (2-D, Plotly frames)
# ─────────────────────────────────────────────────────────────────────────────
def plot_realtime_gradient(X, Y, Z, results, surface, surface_name, animate_step=None):
    if not results:
        st.warning("No results yet — run the optimisation first.")
        return

    Z_c = np.clip(Z, np.percentile(Z,2), np.percentile(Z,98))

    skip  = max(1, X.shape[0]//16)
    Xf    = X[::skip,::skip].flatten()
    Yf    = Y[::skip,::skip].flatten()
    arrow = (X[0,-1]-X[0,0])*0.055
    gx_a, gy_a = [], []
    for xi,yi in zip(Xf,Yf):
        gx,gy = surface.gradient(float(xi), float(yi))
        n = np.sqrt(gx**2+gy**2)+1e-8
        gx_a.append(-gx/n*arrow); gy_a.append(-gy/n*arrow)

    sx,sy=[],[]
    for xi,yi,dxi,dyi in zip(Xf,Yf,gx_a,gy_a):
        sx+=[xi,xi+dxi,None]; sy+=[yi,yi+dyi,None]

    # ── find global minimum — use full-res Z (not clipped) ──────────────────
    Z_full     = surface.compute(X, Y)
    min_idx    = np.unravel_index(np.argmin(Z_full), Z_full.shape)
    gmin_x     = float(X[min_idx])
    gmin_y     = float(Y[min_idx])
    gmin_loss  = float(Z_full[min_idx])

    static = [
        go.Contour(x=X[0,:],y=Y[:,0],z=Z_c,colorscale='Viridis',
                   contours=dict(showlabels=True,labelfont=dict(size=8,color='white')),
                   line=dict(width=0.6),opacity=0.88,showscale=True,
                   colorbar=dict(title=dict(text='Loss',font=dict(color='#94a3b8')),
                                 tickfont=dict(color='#94a3b8'),thickness=12,len=0.8,x=1.01),
                   hovertemplate='x=%{x:.3f}<br>y=%{y:.3f}<br>loss=%{z:.4f}<extra></extra>'),
        go.Scatter(x=sx,y=sy,mode='lines',
                   line=dict(color='rgba(200,200,200,0.20)',width=1),
                   hoverinfo='skip',showlegend=False),
        go.Scatter(x=[xi+dxi for xi,dxi in zip(Xf,gx_a)],
                   y=[yi+dyi for yi,dyi in zip(Yf,gy_a)],
                   mode='markers',
                   marker=dict(symbol='triangle-right',size=4,
                               color='rgba(200,200,200,0.38)',
                               angle=[float(np.degrees(np.arctan2(dy,dx))) for dx,dy in zip(gx_a,gy_a)]),
                   hoverinfo='skip',showlegend=False),
        # ── global minimum — outer pulsing ring ───────────────────────────
        go.Scatter(
            x=[gmin_x], y=[gmin_y],
            mode='markers',
            marker=dict(
                symbol='circle', size=28,
                color='rgba(0,0,0,0)',
                line=dict(color='rgba(255,215,0,0.5)', width=2.5)
            ),
            name='Global Min (ring)', showlegend=False, hoverinfo='skip'
        ),
        # ── global minimum — solid star ────────────────────────────────────
        go.Scatter(
            x=[gmin_x], y=[gmin_y],
            mode='markers+text',
            marker=dict(
                symbol='star', size=22,
                color='#FFD700',
                line=dict(color='white', width=2)
            ),
            text=['Global<br>Min'],
            textposition='top center',
            textfont=dict(color='#FFD700', size=10, family='Inter, sans-serif'),
            name='🎯 Global Minimum',
            showlegend=True,
            hovertemplate=(
                f'<b>🎯 Global Minimum</b><br>'
                f'x = {gmin_x:.4f}<br>'
                f'y = {gmin_y:.4f}<br>'
                f'loss = {gmin_loss:.5f}<extra></extra>'
            )
        ),
    ]

    prepped   = {n: _prep(s) for n,s in results.items()}
    max_steps = max(len(p[0]) for p in prepped.values())

    def dyn(step):
        traces=[]; anns=[]
        for idx,(name,(traj,losses,grads)) in enumerate(prepped.items()):
            col = COLORS[idx%len(COLORS)]
            end = min(step+1, len(traj))
            traces.append(go.Scatter(
                x=traj[:end,0],y=traj[:end,1],mode='lines',name=name,
                line=dict(color=col,width=3),opacity=0.95,
                legendgroup=name, showlegend=True,
                hovertemplate=f'<b>{name}</b><br>x=%{{x:.4f}}<br>y=%{{y:.4f}}<extra></extra>'
            ))
            if end>2:
                traces.append(go.Scatter(
                    x=traj[1:end-1,0],y=traj[1:end-1,1],mode='markers',
                    marker=dict(size=4,color=col,opacity=0.40,line=dict(width=0.5,color='white')),
                    showlegend=False,legendgroup=name,hoverinfo='skip'
                ))
            traces.append(go.Scatter(
                x=[traj[0,0]],y=[traj[0,1]],mode='markers',
                marker=dict(symbol='square',size=9,color=col,line=dict(width=1.5,color='white')),
                showlegend=False,legendgroup=name,
                hovertemplate=f'<b>{name} START</b><extra></extra>'
            ))
            cx,cy = float(traj[end-1,0]), float(traj[end-1,1])
            closs = float(losses[end-1])
            traces.append(go.Scatter(
                x=[cx],y=[cy],mode='markers',
                marker=dict(symbol='star',size=17,color=col,line=dict(width=2,color='white')),
                showlegend=False,legendgroup=name,
                hovertemplate=f'<b>{name}</b> step {end-1}<br>loss={closs:.5f}<extra></extra>'
            ))
            gx_c,gy_c = surface.gradient(cx,cy)
            gn  = np.sqrt(gx_c**2+gy_c**2)+1e-8
            sc  = arrow*3.8
            anns.append(dict(
                x=cx-(gx_c/gn)*sc, y=cy-(gy_c/gn)*sc,
                ax=cx, ay=cy,
                xref='x',yref='y',axref='x',ayref='y',
                showarrow=True,arrowhead=3,arrowsize=1.6,arrowwidth=3.5,arrowcolor=col,
                text=f'<b>∇{name[:5]}</b>',
                font=dict(size=9,color=col),
                bgcolor='rgba(0,0,0,0.65)',bordercolor=col,borderwidth=1,borderpad=2
            ))
        return traces, anns

    init_dyn, init_ann = dyn(0)
    fig = go.Figure(data=static+init_dyn)
    fig.frames = [go.Frame(data=static+d, layout=go.Layout(annotations=a), name=str(s))
                  for s,(d,a) in enumerate(dyn(i) for i in range(max_steps))]
    fig.update_layout(annotations=init_ann)

    layout = _base_layout(
        f'<b>Real-Time Gradient Animation — {surface_name}</b><br>'
        f'<sup>▶ Play to animate · drag slider to scrub</sup>', height=700)
    layout.update(
        xaxis=dict(title='X',showgrid=True,gridcolor='rgba(255,255,255,0.06)',zeroline=False),
        yaxis=dict(title='Y',showgrid=True,gridcolor='rgba(255,255,255,0.06)',zeroline=False,
                   scaleanchor='x'),
        updatemenus=_anim_menus(100),
        sliders=_slider(max_steps),
        margin=dict(l=60,r=40,t=110,b=70),
    )
    fig.update_layout(layout)
    st.plotly_chart(fig, use_container_width=True)


# ─────────────────────────────────────────────────────────────────────────────
# CONVERGENCE ANALYSIS  (all Plotly, 4 panels)
# ─────────────────────────────────────────────────────────────────────────────
def plot_convergence_analysis(results):
    fig = make_subplots(
        rows=2, cols=2,
        subplot_titles=(
            '📉 Loss vs Iteration (log scale)',
            '📍 Distance to Global Minimum',
            '👣 Step Size Evolution',
            '🔥 Gradient Magnitude'
        ),
        vertical_spacing=0.16, horizontal_spacing=0.12
    )

    for idx, (name, state) in enumerate(results.items()):
        col = COLORS[idx % len(COLORS)]

        # ── normalise all arrays to same length ──────────────────────────────
        traj, losses, grads = _prep(state)          # _prep pads losses to len(traj)
        n = len(losses)                             # canonical length

        # step sizes: diff of trajectory → n-1 values, pad with 0 to length n
        raw_steps = np.linalg.norm(np.diff(traj, axis=0), axis=1)
        step_sizes = np.concatenate([[0.0], raw_steps])[:n]   # length n

        # grad norms: may be shorter than n
        if len(grads) >= n:
            grad_arr = np.array(grads[:n])
        elif len(grads) > 0:
            pad_grads = [(0.0, 0.0)] * (n - len(grads))
            grad_arr  = np.array(list(grads) + pad_grads)
        else:
            grad_arr = np.zeros((n, 2))
        grad_norms = np.linalg.norm(grad_arr, axis=1)          # length n

        # distance from final position (approximates distance to minimum)
        final_pos = traj[-1]
        dist_to_min = np.linalg.norm(traj - final_pos, axis=1) # length n

        # clip zeros for log scale
        losses_log     = np.where(losses     <= 0, 1e-12, losses)
        step_sizes_log = np.where(step_sizes <= 0, 1e-12, step_sizes)
        grad_norms_log = np.where(grad_norms <= 0, 1e-12, grad_norms)
        dist_log       = np.where(dist_to_min<= 0, 1e-12, dist_to_min)

        xs = list(range(n))
        kw = dict(line=dict(color=col, width=2.4), name=name, legendgroup=name,
                  mode='lines')

        # find convergence step (within 5% of best loss)
        best_l = float(np.min(losses_log))
        conv_step = next((i for i, l in enumerate(losses_log) if l <= best_l * 1.05), n-1)

        # panel 1 — loss
        fig.add_trace(go.Scatter(x=xs, y=losses_log.tolist(), showlegend=True, **kw), row=1, col=1)
        fig.add_trace(go.Scatter(
            x=[conv_step], y=[float(losses_log[conv_step])],
            mode='markers',
            marker=dict(symbol='star', size=12, color=col,
                        line=dict(width=1.5, color='white')),
            name=f'{name} converged', showlegend=False, legendgroup=name,
            hovertemplate=f'<b>{name}</b> converged @ step {conv_step}<br>loss={losses_log[conv_step]:.5f}<extra></extra>'
        ), row=1, col=1)

        # panel 2 — distance to min
        fig.add_trace(go.Scatter(x=xs, y=dist_log.tolist(), showlegend=False,
                                 **{**kw}), row=1, col=2)

        # panel 3 — step size
        fig.add_trace(go.Scatter(x=xs, y=step_sizes_log.tolist(), showlegend=False,
                                 **{**kw}), row=2, col=1)

        # panel 4 — gradient norm
        fig.add_trace(go.Scatter(x=xs, y=grad_norms_log.tolist(), showlegend=False,
                                 **{**kw}), row=2, col=2)

    # axis styling
    axis_style = dict(gridcolor='rgba(255,255,255,0.07)',
                      tickfont=dict(color='#94a3b8'), zerolinecolor='rgba(255,255,255,0.05)')
    for r, c in [(1,1),(1,2),(2,1),(2,2)]:
        fig.update_yaxes(type='log', **axis_style, row=r, col=c)
        fig.update_xaxes(title_text='Step', **axis_style, row=r, col=c)

    _cl = _base_layout('<b>Convergence Analysis</b>', height=680)
    _cl['showlegend'] = True
    _cl['plot_bgcolor'] = '#0d1117'
    fig.update_layout(_cl)
    for ann in fig.layout.annotations:
        ann.font.color = '#cbd5e1'
        ann.font.size  = 13
    st.plotly_chart(fig, use_container_width=True)


# ─────────────────────────────────────────────────────────────────────────────
# METRICS TABLE
# ─────────────────────────────────────────────────────────────────────────────
def create_metrics_table(results, n_steps):
    rows = []
    for name,state in results.items():
        traj       = np.array(state.trajectory)
        losses     = np.array(state.loss_history, dtype=float)
        best_loss  = float(np.min(losses)) if len(losses) else 0
        final_loss = float(losses[-1])     if len(losses) else 0
        step_sizes = np.linalg.norm(np.diff(traj,axis=0),axis=1)
        grads      = np.array(state.grad_history)
        grad_norms = np.linalg.norm(grads,axis=1) if len(grads) else np.zeros(1)
        conv       = next((i for i,l in enumerate(losses) if l<=best_loss*1.1), n_steps)
        rows.append({
            'Optimizer':        name,
            'Final Loss':       f'{final_loss:.6f}',
            'Best Loss':        f'{best_loss:.6f}',
            'Convergence Step': conv,
            'Avg Step Size':    f'{np.mean(step_sizes):.5f}',
            'Avg Grad Norm':    f'{np.mean(grad_norms):.5f}',
            'Max Grad':         f'{np.max(grad_norms):.5f}',
            'Dist to Origin':   f'{np.linalg.norm(traj[-1]):.5f}',
        })
    return pd.DataFrame(rows)


# ─────────────────────────────────────────────────────────────────────────────
# EXPLORATION vs EXPLOITATION  (Plotly bar charts)
# ─────────────────────────────────────────────────────────────────────────────
def plot_exploration_exploitation(results):
    expl_data, expt_data = [], []
    for name,state in results.items():
        traj      = np.array(state.trajectory)
        ss        = np.linalg.norm(np.diff(traj,axis=0),axis=1)
        half      = len(ss)//2 or 1
        early,late= ss[:half], ss[half:]
        expl_data.append({'Optimizer':name, 'Exploration (std early steps)': float(np.std(early))})
        expt_data.append({'Optimizer':name, 'Exploitation (1/std late steps)': float(1/(np.std(late)+1e-8))})

    col1,col2 = st.columns(2)
    with col1:
        df = pd.DataFrame(expl_data)
        fig = px.bar(df, x='Optimizer', y='Exploration (std early steps)',
                     color='Optimizer', color_discrete_sequence=COLORS,
                     title='Early-Stage Exploration')
        fig.update_layout(**_base_layout('', height=380))
        fig.update_traces(marker_line_width=0)
        st.plotly_chart(fig, use_container_width=True)
    with col2:
        df = pd.DataFrame(expt_data)
        fig = px.bar(df, x='Optimizer', y='Exploitation (1/std late steps)',
                     color='Optimizer', color_discrete_sequence=COLORS,
                     title='Late-Stage Exploitation')
        fig.update_layout(**_base_layout('', height=380))
        fig.update_traces(marker_line_width=0)
        st.plotly_chart(fig, use_container_width=True)


def plot_exploration_heatmap(results):
    st.markdown('#### Step-Size Heatmap Over Training')
    optimizer_names, heatmap_data = [], []
    for name,state in results.items():
        traj   = np.array(state.trajectory)
        ss     = np.linalg.norm(np.diff(traj,axis=0),axis=1)
        w      = max(1, len(ss)//20)
        smooth = np.convolve(ss, np.ones(w)/w, mode='valid')
        heatmap_data.append(smooth)
        optimizer_names.append(name)
    ml = max(len(h) for h in heatmap_data)
    data = np.array([np.pad(h,(0,ml-len(h)),'edge') for h in heatmap_data])
    fig = go.Figure(go.Heatmap(
        z=data, y=optimizer_names,
        colorscale='Hot', showscale=True,
        colorbar=dict(title=dict(text='Step Size',font=dict(color='#94a3b8')),
                      tickfont=dict(color='#94a3b8'))
    ))
    layout = _base_layout('Exploration vs Exploitation Over Time', height=320)
    layout.update(
        xaxis=dict(title='Training Progress →', tickfont=dict(color='#94a3b8')),
        yaxis=dict(tickfont=dict(color='#94a3b8')),
    )
    fig.update_layout(layout)
    st.plotly_chart(fig, use_container_width=True)


# ─────────────────────────────────────────────────────────────────────────────
# WINNERS BANNER
# ─────────────────────────────────────────────────────────────────────────────
def display_winners(results):
    best   = min(results.items(), key=lambda x: min(x[1].loss_history))
    fastest= min(results.items(), key=lambda x: next(
        (i for i,l in enumerate(x[1].loss_history) if l<=min(x[1].loss_history)*1.1), float('inf')))
    stable = min(results.items(), key=lambda x: np.std(np.diff(x[1].loss_history)))

    c1,c2,c3 = st.columns(3)
    with c1:
        st.metric('🏆 Best Final Loss',  best[0],    f'{min(best[1].loss_history):.6f}')
    with c2:
        st.metric('⚡ Fastest Convergence', fastest[0])
    with c3:
        st.metric('🎯 Most Stable', stable[0], 'Min Loss Variance')


# ─────────────────────────────────────────────────────────────────────────────
# GRID SEARCH RESULTS  (Plotly)
# ─────────────────────────────────────────────────────────────────────────────
def plot_grid_search_results(optimizers_results):
    n = len(optimizers_results)
    fig = make_subplots(rows=1, cols=n,
                        subplot_titles=list(optimizers_results.keys()),
                        horizontal_spacing=0.08)
    for ci,(opt_type,lr_configs) in enumerate(optimizers_results.items(),1):
        for i,(lr,state) in enumerate(lr_configs):
            fig.add_trace(go.Scatter(
                y=state.loss_history, mode='lines', name=f'LR={lr:.4f}',
                line=dict(color=COLORS[i%len(COLORS)], width=1.8),
                showlegend=(ci==1)
            ), row=1, col=ci)
        fig.update_yaxes(type='log', row=1, col=ci,
                         gridcolor='rgba(255,255,255,0.07)')
        fig.update_xaxes(title_text='Step', row=1, col=ci,
                         gridcolor='rgba(255,255,255,0.07)')
    fig.update_layout(**_base_layout('<b>Grid Search Results</b>', height=400))
    for ann in fig.layout.annotations:
        ann.font.color='#cbd5e1'
    st.plotly_chart(fig, use_container_width=True)


def plot_lr_vs_convergence(lr_range, conv_sgd, conv_adam):
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=lr_range,y=conv_sgd, mode='lines+markers',
                             name='SGD', line=dict(color=COLORS[0],width=2.5),
                             marker=dict(size=8)))
    fig.add_trace(go.Scatter(x=lr_range,y=conv_adam, mode='lines+markers',
                             name='Adam', line=dict(color=COLORS[1],width=2.5),
                             marker=dict(size=8)))
    layout = _base_layout('<b>Convergence Speed vs Learning Rate</b>', height=400)
    layout.update(
        xaxis=dict(title='Learning Rate', type='log',
                   gridcolor='rgba(255,255,255,0.07)'),
        yaxis=dict(title='Steps to Converge',
                   gridcolor='rgba(255,255,255,0.07)'),
    )
    fig.update_layout(layout)
    st.plotly_chart(fig, use_container_width=True)


# ─────────────────────────────────────────────────────────────────────────────
# BATCH EXPERIMENT DISTRIBUTIONS  (Plotly)
# ─────────────────────────────────────────────────────────────────────────────
def plot_batch_distributions(results_opt1, results_opt2, opt1_name, opt2_name):
    r1 = np.array(results_opt1, dtype=float)
    r2 = np.array(results_opt2, dtype=float)

    fig = make_subplots(
        rows=1, cols=2,
        subplot_titles=(f'{opt1_name} — Final Loss Distribution',
                        f'{opt2_name} — Final Loss Distribution')
    )

    for ci, (data, name) in enumerate([(r1, opt1_name), (r2, opt2_name)], 1):
        color = COLORS[ci - 1]
        mean_val = float(np.mean(data))

        # histogram bars
        fig.add_trace(go.Histogram(
            x=data.tolist(), nbinsx=20, name=name,
            marker=dict(color=color, opacity=0.82,
                        line=dict(color='rgba(255,255,255,0.3)', width=0.8)),
            showlegend=False
        ), row=1, col=ci)

        # mean vertical line via a scatter trick (works in subplots)
        y_max = max(1, len(data) // 3)
        fig.add_trace(go.Scatter(
            x=[mean_val, mean_val], y=[0, y_max],
            mode='lines+text',
            line=dict(color='white', width=2, dash='dash'),
            text=['', f'μ={mean_val:.4f}'],
            textposition='top center',
            textfont=dict(color='white', size=11),
            showlegend=False
        ), row=1, col=ci)

    # axis styling
    for ci in [1, 2]:
        fig.update_xaxes(title_text='Final Loss', row=1, col=ci,
                         gridcolor='rgba(255,255,255,0.06)',
                         tickfont=dict(color='#94a3b8'))
        fig.update_yaxes(title_text='Count', row=1, col=ci,
                         gridcolor='rgba(255,255,255,0.06)',
                         tickfont=dict(color='#94a3b8'))

    _bl = _base_layout('<b>Final Loss Distributions Across Trials</b>', height=420)
    _bl['showlegend'] = False
    fig.update_layout(_bl)
    for ann in fig.layout.annotations:
        ann.font.color = '#cbd5e1'
        ann.font.size  = 13
    st.plotly_chart(fig, use_container_width=True)


# ─────────────────────────────────────────────────────────────────────────────
# EDUCATIONAL HELPERS
# ─────────────────────────────────────────────────────────────────────────────
def display_step_metrics(state_edu, surface_edu):
    x_curr, y_curr = state_edu.params
    loss_curr = surface_edu.compute(np.array([x_curr]), np.array([y_curr]))[0]
    c1,c2,c3,c4 = st.columns(4)
    with c1: st.metric('X Position',   f'{x_curr:.4f}')
    with c2: st.metric('Y Position',   f'{y_curr:.4f}')
    with c3: st.metric('Current Loss', f'{loss_curr:.6f}')
    with c4:
        if state_edu.grad_history:
            gx,gy = state_edu.grad_history[-1]
            st.metric('Gradient Norm', f'{np.sqrt(gx**2+gy**2):.6f}')


def display_optimizer_math(optimizer_name, edu_lr, state_edu):
    st.markdown('#### Mathematical Update Rule')
    if optimizer_name == 'SGD':
        st.latex(r'\theta_{t+1} = \theta_t - \alpha \nabla f(\theta_t)')
        if state_edu.grad_history:
            gx,gy = state_edu.grad_history[-1]
            x,y   = state_edu.params
            st.info(f'θ = ({x:.4f}, {y:.4f})   |   ∇f = ({gx:.4f}, {gy:.4f})   |   ‖∇f‖ = {np.sqrt(gx**2+gy**2):.6f}')
    elif optimizer_name == 'Momentum':
        st.latex(r'v_t = \beta v_{t-1} + (1-\beta)\nabla f(\theta_t)')
        st.latex(r'\theta_{t+1} = \theta_t - \alpha v_t')
        if state_edu.velocity is not None:
            st.info(f'Velocity: {state_edu.velocity}')
    else:
        st.latex(r'm_t = \beta_1 m_{t-1} + (1-\beta_1)\nabla f')
        st.latex(r'v_t = \beta_2 v_{t-1} + (1-\beta_2)(\nabla f)^2')
        st.latex(r'\theta_{t+1} = \theta_t - \alpha\frac{\hat m_t}{\sqrt{\hat v_t}+\epsilon}')
        if state_edu.m is not None:
            st.info(f'm = {state_edu.m}   |   v = {state_edu.v}')


# ─────────────────────────────────────────────────────────────────────────────
# STABILITY TEST PLOT  (Plotly)
# ─────────────────────────────────────────────────────────────────────────────
def plot_stability_test(state):
    fig = go.Figure(go.Scatter(
        y=state.loss_history, mode='lines',
        line=dict(color=COLORS[2], width=2.5), name='Loss'
    ))
    layout = _base_layout('<b>Stability Test — Loss over Steps</b>', height=380)
    layout.update(
        xaxis=dict(title='Step', gridcolor='rgba(255,255,255,0.07)'),
        yaxis=dict(title='Loss', gridcolor='rgba(255,255,255,0.07)'),
    )
    fig.update_layout(layout)
    st.plotly_chart(fig, use_container_width=True)