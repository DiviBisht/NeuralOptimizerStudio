import numpy as np
from dataclasses import dataclass
from typing import List, Tuple



@dataclass
class OptimizerState:
    params: np.ndarray
    trajectory: List[np.ndarray]
    loss_history: List[float]
    grad_history: List[Tuple[float, float]]
    velocity: np.ndarray = None
    m: np.ndarray = None
    v: np.ndarray = None
    t: int = 0
    slow_params: np.ndarray = None




class Optimizer:
    def __init__(self, learning_rate: float):
        self.learning_rate = learning_rate
        self.name = "Base"
    
    def step(self, state: OptimizerState, gradient: Tuple[float, float], loss: float):
       
        raise NotImplementedError
    
    def init_state(self, params: np.ndarray) -> OptimizerState:
       
        return OptimizerState(params.copy(), [params.copy()], [0.0], [])




class SGD(Optimizer):
    def __init__(self, learning_rate: float = 0.01):
        super().__init__(learning_rate)
        self.name = "SGD"
    
    def step(self, state: OptimizerState, gradient: Tuple[float, float], loss: float):
        grad = np.array(gradient)
        state.params -= self.learning_rate * grad
        state.trajectory.append(state.params.copy())
        state.loss_history.append(loss)
        state.grad_history.append(gradient)


class Momentum(Optimizer):
    def __init__(self, learning_rate: float = 0.01, beta: float = 0.9):
        super().__init__(learning_rate)
        self.beta = beta
        self.name = f"Momentum"
    
    def init_state(self, params: np.ndarray) -> OptimizerState:
        state = super().init_state(params)
        state.velocity = np.zeros_like(params)
        return state
    
    def step(self, state: OptimizerState, gradient: Tuple[float, float], loss: float):
        grad = np.array(gradient)
        state.velocity = self.beta * state.velocity - self.learning_rate * grad
        state.params += state.velocity
        state.trajectory.append(state.params.copy())
        state.loss_history.append(loss)
        state.grad_history.append(gradient)


class Nesterov(Optimizer):
    def __init__(self, learning_rate: float = 0.01, beta: float = 0.9):
        super().__init__(learning_rate)
        self.beta = beta
        self.name = f"Nesterov"
    
    def init_state(self, params: np.ndarray) -> OptimizerState:
        state = super().init_state(params)
        state.velocity = np.zeros_like(params)
        return state
    
    def step(self, state: OptimizerState, gradient: Tuple[float, float], loss: float):
        grad = np.array(gradient)
        state.velocity = self.beta * state.velocity - self.learning_rate * grad
        state.params += self.beta * state.velocity - self.learning_rate * grad
        state.trajectory.append(state.params.copy())
        state.loss_history.append(loss)
        state.grad_history.append(gradient)



class AdaGrad(Optimizer):
    def __init__(self, learning_rate: float = 0.01, epsilon: float = 1e-8):
        super().__init__(learning_rate)
        self.epsilon = epsilon
        self.name = "AdaGrad"
    
    def init_state(self, params: np.ndarray) -> OptimizerState:
        state = super().init_state(params)
        state.m = np.zeros_like(params)
        return state
    
    def step(self, state: OptimizerState, gradient: Tuple[float, float], loss: float):
        grad = np.array(gradient)
        state.m += grad**2
        state.params -= self.learning_rate * grad / (np.sqrt(state.m) + self.epsilon)
        state.trajectory.append(state.params.copy())
        state.loss_history.append(loss)
        state.grad_history.append(gradient)


class RMSProp(Optimizer):
    def __init__(self, learning_rate: float = 0.01, beta: float = 0.9, epsilon: float = 1e-8):
        super().__init__(learning_rate)
        self.beta = beta
        self.epsilon = epsilon
        self.name = f"RMSProp"
    
    def init_state(self, params: np.ndarray) -> OptimizerState:
        state = super().init_state(params)
        state.m = np.zeros_like(params)
        return state
    
    def step(self, state: OptimizerState, gradient: Tuple[float, float], loss: float):
        grad = np.array(gradient)
        state.m = self.beta * state.m + (1 - self.beta) * grad**2
        state.params -= self.learning_rate * grad / (np.sqrt(state.m) + self.epsilon)
        state.trajectory.append(state.params.copy())
        state.loss_history.append(loss)
        state.grad_history.append(gradient)


class Adam(Optimizer):
    def __init__(self, learning_rate: float = 0.001, beta1: float = 0.9, beta2: float = 0.999, epsilon: float = 1e-8):
        super().__init__(learning_rate)
        self.beta1 = beta1
        self.beta2 = beta2
        self.epsilon = epsilon
        self.name = "Adam"
    
    def init_state(self, params: np.ndarray) -> OptimizerState:
        state = super().init_state(params)
        state.m = np.zeros_like(params)
        state.v = np.zeros_like(params)
        state.t = 0
        return state
    
    def step(self, state: OptimizerState, gradient: Tuple[float, float], loss: float):
        grad = np.array(gradient)
        state.t += 1
        state.m = self.beta1 * state.m + (1 - self.beta1) * grad
        state.v = self.beta2 * state.v + (1 - self.beta2) * grad**2
        m_hat = state.m / (1 - self.beta1**state.t)
        v_hat = state.v / (1 - self.beta2**state.t)
        state.params -= self.learning_rate * m_hat / (np.sqrt(v_hat) + self.epsilon)
        state.trajectory.append(state.params.copy())
        state.loss_history.append(loss)
        state.grad_history.append(gradient)


class AdamW(Optimizer):
    def __init__(self, learning_rate: float = 0.001, beta1: float = 0.9, beta2: float = 0.999, epsilon: float = 1e-8, weight_decay: float = 0.01):
        super().__init__(learning_rate)
        self.beta1 = beta1
        self.beta2 = beta2
        self.epsilon = epsilon
        self.weight_decay = weight_decay
        self.name = "AdamW"
    
    def init_state(self, params: np.ndarray) -> OptimizerState:
        state = super().init_state(params)
        state.m = np.zeros_like(params)
        state.v = np.zeros_like(params)
        state.t = 0
        return state
    
    def step(self, state: OptimizerState, gradient: Tuple[float, float], loss: float):
        grad = np.array(gradient)
        state.t += 1
        state.m = self.beta1 * state.m + (1 - self.beta1) * grad
        state.v = self.beta2 * state.v + (1 - self.beta2) * grad**2
        m_hat = state.m / (1 - self.beta1**state.t)
        v_hat = state.v / (1 - self.beta2**state.t)
        state.params -= self.learning_rate * (m_hat / (np.sqrt(v_hat) + self.epsilon) + self.weight_decay * state.params)
        state.trajectory.append(state.params.copy())
        state.loss_history.append(loss)
        state.grad_history.append(gradient)


class RAdam(Optimizer):
    def __init__(self, learning_rate: float = 0.001, beta1: float = 0.9, beta2: float = 0.999, epsilon: float = 1e-8):
        super().__init__(learning_rate)
        self.beta1 = beta1
        self.beta2 = beta2
        self.epsilon = epsilon
        self.name = "RAdam"
    
    def init_state(self, params: np.ndarray) -> OptimizerState:
        state = super().init_state(params)
        state.m = np.zeros_like(params)
        state.v = np.zeros_like(params)
        state.t = 0
        return state
    
    def step(self, state: OptimizerState, gradient: Tuple[float, float], loss: float):
        grad = np.array(gradient)
        state.t += 1
        state.m = self.beta1 * state.m + (1 - self.beta1) * grad
        state.v = self.beta2 * state.v + (1 - self.beta2) * grad**2
        rho_inf = 2 / (1 - self.beta2) - 1
        rho_t = rho_inf - 2 * state.t * (self.beta2**state.t) / (1 - self.beta2**state.t)
        
        if rho_t > 4:
            rect = np.sqrt((rho_t - 4) * (rho_t - 2) * rho_inf / ((rho_inf - 4) * (rho_inf - 2) * rho_t))
            state.params -= self.learning_rate * rect * state.m / (np.sqrt(state.v) + self.epsilon)
        else:
            state.params -= self.learning_rate * state.m
        
        state.trajectory.append(state.params.copy())
        state.loss_history.append(loss)
        state.grad_history.append(gradient)


class LAMB(Optimizer):
    def __init__(self, learning_rate: float = 0.001, beta1: float = 0.9, beta2: float = 0.999):
        super().__init__(learning_rate)
        self.beta1 = beta1
        self.beta2 = beta2
        self.name = "LAMB"
    
    def init_state(self, params: np.ndarray) -> OptimizerState:
        state = super().init_state(params)
        state.m = np.zeros_like(params)
        state.v = np.zeros_like(params)
        state.t = 0
        return state
    
    def step(self, state: OptimizerState, gradient: Tuple[float, float], loss: float):
        grad = np.array(gradient)
        state.t += 1
        state.m = self.beta1 * state.m + (1 - self.beta1) * grad
        state.v = self.beta2 * state.v + (1 - self.beta2) * grad**2
        m_hat = state.m / (1 - self.beta1**state.t)
        v_hat = state.v / (1 - self.beta2**state.t)
        
        r = m_hat / (np.sqrt(v_hat) + 1e-8)
        w_norm = np.linalg.norm(state.params)
        r_norm = np.linalg.norm(r)
        trust_ratio = w_norm / (r_norm + 1e-8)
        state.params -= self.learning_rate * trust_ratio * r
        state.trajectory.append(state.params.copy())
        state.loss_history.append(loss)
        state.grad_history.append(gradient)



class Lookahead(Optimizer):
    def __init__(self, optimizer: Optimizer, k: int = 5, alpha: float = 0.5):
        super().__init__(optimizer.learning_rate)
        self.optimizer = optimizer
        self.k = k
        self.alpha = alpha
        self.name = f"Lookahead({optimizer.name})"
        self.step_counter = 0
    
    def init_state(self, params: np.ndarray) -> OptimizerState:
        state = self.optimizer.init_state(params)
        state.slow_params = params.copy()
        return state
    
    def step(self, state: OptimizerState, gradient: Tuple[float, float], loss: float):
        self.optimizer.step(state, gradient, loss)
        self.step_counter += 1
        
        if self.step_counter % self.k == 0:
            state.slow_params = self.alpha * state.params + (1 - self.alpha) * state.slow_params
            state.params = state.slow_params.copy()
            state.trajectory[-1] = state.params.copy()


class LBFGS(Optimizer):
    def __init__(self, learning_rate: float = 0.01):
        super().__init__(learning_rate)
        self.name = "L-BFGS"
        self.H = None
    
    def init_state(self, params: np.ndarray) -> OptimizerState:
        state = super().init_state(params)
        self.H = np.eye(len(params))
        return state
    
    def step(self, state: OptimizerState, gradient: Tuple[float, float], loss: float):
        grad = np.array(gradient)
        
        if len(state.grad_history) > 0:
            prev_grad = np.array(state.grad_history[-1])
            y = grad - prev_grad
            s = -self.learning_rate * np.dot(self.H, prev_grad)
            
            if np.dot(y, s) > 1e-8:
                self.H = self.H - np.outer(np.dot(self.H, y), np.dot(y, self.H)) / np.dot(y, np.dot(self.H, y)) + \
                         np.outer(s, s) / np.dot(y, s)
        
        step = -self.learning_rate * np.dot(self.H, grad)
        state.params += step
        state.trajectory.append(state.params.copy())
        state.loss_history.append(loss)
        state.grad_history.append(tuple(gradient))


class Newton(Optimizer):
    def __init__(self, learning_rate: float = 0.01):
        super().__init__(learning_rate)
        self.name = "Newton"
    
    def step(self, state: OptimizerState, gradient: Tuple[float, float], loss: float):
        grad = np.array(gradient)
        eps = 1e-4
        H = np.zeros((2, 2))
        
        for i in range(2):
            for j in range(2):
                delta_i = np.zeros(2)
                delta_j = np.zeros(2)
                delta_i[i] = eps
                delta_j[j] = eps
                H[i, j] = (grad[i] + grad[j]) / (eps**2)
        
        try:
            step = np.linalg.solve(H + 1e-6*np.eye(2), grad)
            state.params -= self.learning_rate * step
        except:
            state.params -= self.learning_rate * grad
        
        state.trajectory.append(state.params.copy())
        state.loss_history.append(loss)
        state.grad_history.append(tuple(gradient))


class RandomSearch(Optimizer):
    def __init__(self, learning_rate: float = 0.1):
        super().__init__(learning_rate)
        self.name = "Random Search"
    
    def step(self, state: OptimizerState, gradient: Tuple[float, float], loss: float):
        state.params += np.random.randn(2) * self.learning_rate
        state.trajectory.append(state.params.copy())
        state.loss_history.append(loss)
        state.grad_history.append(tuple(gradient))




def get_learning_rate(base_lr: float, schedule: str, step: int, total_steps: int) -> float:
    if schedule == "constant":
        return base_lr
    elif schedule == "linear_decay":
        return base_lr * (1 - step / total_steps)
    elif schedule == "exponential":
        return base_lr * (0.95 ** (step / 10))
    elif schedule == "cosine_annealing":
        return base_lr * (1 + np.cos(np.pi * step / total_steps)) / 2
    elif schedule == "step_decay":
        return base_lr * (0.1 ** (step // (total_steps // 3)))
    elif schedule == "warmup":
        warmup_steps = total_steps // 10
        if step < warmup_steps:
            return base_lr * (step / warmup_steps)
        else:
            return base_lr * (1 - (step - warmup_steps) / (total_steps - warmup_steps))
    else:
        return base_lr




def create_optimizer(name: str, learning_rate: float) -> Optimizer:
    optimizers = {
        "SGD": lambda: SGD(learning_rate),
        "Momentum": lambda: Momentum(learning_rate),
        "Nesterov": lambda: Nesterov(learning_rate),
        "AdaGrad": lambda: AdaGrad(learning_rate),
        "RMSProp": lambda: RMSProp(learning_rate),
        "Adam": lambda: Adam(learning_rate),
        "AdamW": lambda: AdamW(learning_rate),
        "RAdam": lambda: RAdam(learning_rate),
        "LAMB": lambda: LAMB(learning_rate),
        "L-BFGS": lambda: LBFGS(learning_rate),
        "Newton": lambda: Newton(learning_rate),
        "Random Search": lambda: RandomSearch(learning_rate)
    }
    return optimizers[name]()