import streamlit as st
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from tensorflow import keras
from tensorflow.keras import layers
import tensorflow as tf




def build_mnist_model():
    
    model = keras.Sequential([
        layers.Flatten(input_shape=(28, 28)),
        layers.Dense(128, activation='relu'),
        layers.Dropout(0.2),
        layers.Dense(64, activation='relu'),
        layers.Dropout(0.2),
        layers.Dense(10, activation='softmax')
    ])
    return model


def get_tf_optimizer(optimizer_name, learning_rate):
    
    if optimizer_name == "SGD":
        return tf.keras.optimizers.SGD(learning_rate=learning_rate)
    elif optimizer_name == "Momentum":
        return tf.keras.optimizers.SGD(learning_rate=learning_rate, momentum=0.9)
    elif optimizer_name == "Adam":
        return tf.keras.optimizers.Adam(learning_rate=learning_rate)
    elif optimizer_name == "AdamW":
        return tf.keras.optimizers.experimental.AdamW(learning_rate=learning_rate)
    else:  
        return tf.keras.optimizers.experimental.RectifiedAdam(learning_rate=learning_rate)


def train_mnist_model(epochs, batch_size, optimizer_name, learning_rate):
    
    st.subheader("Training Progress")
    
   
    (x_train, y_train), (x_test, y_test) = keras.datasets.mnist.load_data()
    x_train = x_train[:5000] / 255.0
    y_train = y_train[:5000]
    x_test = x_test[:1000] / 255.0
    y_test = y_test[:1000]
    

    model = build_mnist_model()
    

    opt = get_tf_optimizer(optimizer_name, learning_rate)
    
    model.compile(optimizer=opt, loss='sparse_categorical_crossentropy', metrics=['accuracy'])
    

    history = model.fit(x_train, y_train, epochs=epochs, batch_size=batch_size,
                      validation_split=0.2, verbose=0)
    

    test_loss, test_acc = model.evaluate(x_test, y_test, verbose=0)
    
    return history, test_loss, test_acc, model


def plot_training_history(history):
    """Plot training and validation metrics"""
    fig, axes = plt.subplots(1, 2, figsize=(12, 4))
    
    axes[0].plot(history.history['loss'], label='Train Loss', linewidth=2)
    axes[0].plot(history.history['val_loss'], label='Val Loss', linewidth=2)
    axes[0].set_xlabel("Epoch")
    axes[0].set_ylabel("Loss")
    axes[0].set_title("Loss History")
    axes[0].legend()
    axes[0].grid(True, alpha=0.3)
    
    axes[1].plot(history.history['accuracy'], label='Train Acc', linewidth=2)
    axes[1].plot(history.history['val_accuracy'], label='Val Acc', linewidth=2)
    axes[1].set_xlabel("Epoch")
    axes[1].set_ylabel("Accuracy")
    axes[1].set_title("Accuracy History")
    axes[1].legend()
    axes[1].grid(True, alpha=0.3)
    
    plt.tight_layout()
    st.pyplot(fig)
    plt.close()


def plot_weight_distributions(model):
    """Plot weight distributions of model layers"""
    st.subheader("Weight Distribution Analysis")
    
    weights = model.get_weights()
    fig, axes = plt.subplots(1, min(3, len(weights)), figsize=(14, 4))
    if len(weights) < 3:
        axes = [axes] if len(weights) == 1 else axes
    
    for idx, w in enumerate(weights[:3]):
        axes[idx].hist(w.flatten(), bins=50, alpha=0.7, edgecolor='black')
        axes[idx].set_title(f"Layer {idx} Weights")
        axes[idx].set_xlabel("Weight Value")
        axes[idx].set_ylabel("Frequency")
        axes[idx].grid(True, alpha=0.3)
    
    plt.tight_layout()
    st.pyplot(fig)
    plt.close()


def display_training_metrics(history, test_acc):
    """Display training metrics"""
    col1, col2, col3 = st.columns(3)
    with col1:
        st.metric("Final Train Accuracy", f"{history.history['accuracy'][-1]:.4f}")
    with col2:
        st.metric("Final Val Accuracy", f"{history.history['val_accuracy'][-1]:.4f}")
    with col3:
        st.metric("Test Accuracy", f"{test_acc:.4f}")


def run_batch_experiment(surface, optimizer1, optimizer2, num_trials, n_steps=100):
    """Run batch experiments comparing two optimizers.

    Key fixes:
    - Fresh optimizer instance per trial (avoids state bleed across trials)
    - Use loss_history[1:] to skip the dummy 0.0 initialisation value
    - Start positions clamped to surface bounds
    - Gradient clipping to prevent NaN/inf on steep surfaces
    """
    import copy

    results_opt1 = []
    results_opt2 = []

    lo, hi = surface.bounds[0], surface.bounds[1]
    progress_bar = st.progress(0)

    def run_one(opt_template, x_start, y_start):
        """Run a single trial with a fresh copy of the optimizer."""
        opt   = copy.deepcopy(opt_template)   # fresh state every trial
        state = opt.init_state(np.array([x_start, y_start]))
        base_lr = opt.learning_rate

        for step in range(n_steps):
            x, y = state.params
            # skip if diverged
            if np.isnan(x) or np.isnan(y) or np.abs(x) > 1e6 or np.abs(y) > 1e6:
                break
            loss = float(surface.compute(np.array([x]), np.array([y]))[0])
            grad_x, grad_y = surface.gradient(x, y)
            # gradient clipping
            gnorm = np.sqrt(grad_x**2 + grad_y**2) + 1e-8
            if gnorm > 10.0:
                grad_x, grad_y = grad_x/gnorm*10.0, grad_y/gnorm*10.0
            opt.step(state, (grad_x, grad_y), loss)

        # skip dummy 0.0 init value — only look at actual recorded losses
        real_losses = state.loss_history[1:] if len(state.loss_history) > 1 else state.loss_history
        return float(min(real_losses)) if real_losses else float(loss)

    for trial in range(num_trials):
        # start inside surface bounds
        x_start = np.random.uniform(lo, hi)
        y_start = np.random.uniform(lo, hi)

        results_opt1.append(run_one(optimizer1, x_start, y_start))
        results_opt2.append(run_one(optimizer2, x_start, y_start))

        progress_bar.progress((trial + 1) / num_trials)

    return results_opt1, results_opt2


def display_batch_statistics(results_opt1, results_opt2, opt1_name, opt2_name):
    """Display statistical results from batch experiments"""
    st.markdown("#### 📊 Statistical Results")

    col1, col2 = st.columns(2)

    def _fmt(v): return f"{v:.6f}" if abs(v) >= 1e-6 else f"{v:.2e}"

    with col1:
        st.markdown(f"##### {opt1_name}")
        r = np.array(results_opt1, dtype=float)
        c1a, c1b = st.columns(2)
        with c1a:
            st.metric("Mean Final Loss", _fmt(float(np.mean(r))))
            st.metric("Best Trial",      _fmt(float(np.min(r))))
        with c1b:
            st.metric("Std Dev",         _fmt(float(np.std(r))))
            st.metric("Worst Trial",     _fmt(float(np.max(r))))

    with col2:
        st.markdown(f"##### {opt2_name}")
        r = np.array(results_opt2, dtype=float)
        c2a, c2b = st.columns(2)
        with c2a:
            st.metric("Mean Final Loss", _fmt(float(np.mean(r))))
            st.metric("Best Trial",      _fmt(float(np.min(r))))
        with c2b:
            st.metric("Std Dev",         _fmt(float(np.std(r))))
            st.metric("Worst Trial",     _fmt(float(np.max(r))))


def determine_batch_winner(results_opt1, results_opt2, opt1_name, opt2_name):
    """Determine and display winner of batch experiments"""
    m1 = float(np.mean(results_opt1))
    m2 = float(np.mean(results_opt2))
    if m1 < m2:
        winner, loser, wm, lm = opt1_name, opt2_name, m1, m2
    else:
        winner, loser, wm, lm = opt2_name, opt1_name, m2, m1
    margin = abs(m1 - m2)
    pct    = (margin / (abs(lm) + 1e-12)) * 100

    st.markdown(
        f'<div style="background:linear-gradient(135deg,rgba(108,99,255,0.15),rgba(78,205,196,0.10));'
        f'border:1px solid rgba(108,99,255,0.35);border-radius:12px;padding:1rem 1.4rem;margin-top:.6rem;">' 
        f'<div style="font-size:1.1rem;font-weight:700;color:#e2e8f0;margin-bottom:.3rem;">'
        f'🏆 Winner: <span style="color:#FFD700">{winner}</span></div>'
        f'<div style="color:#94a3b8;font-size:.9rem;">'
        f'Mean loss <b style="color:#4ECDC4">{wm:.6f}</b> vs '
        f'<b style="color:#FF6B6B">{lm:.6f}</b> ({loser}) &nbsp;·&nbsp; '
        f'<b style="color:#a78bfa">{pct:.1f}% better</b></div>'
        f'</div>',
        unsafe_allow_html=True
    )




def run_grid_search(surface, optimizer_class, lr_range, x_init, y_init, n_steps):
    """Run grid search over learning rates"""
    best_loss = float('inf')
    best_lr = None
    best_state = None
    all_results = []
    
    for lr in lr_range:
        optimizer = optimizer_class(lr)
        state = optimizer.init_state(np.array([x_init, y_init]))
        
        for step in range(n_steps):
            x, y = state.params
            loss = surface.compute(np.array([x]), np.array([y]))[0]
            grad_x, grad_y = surface.gradient(x, y)
            optimizer.step(state, (grad_x, grad_y), loss)
        
        final_loss = state.loss_history[-1]
        all_results.append((lr, state))
        
        if final_loss < best_loss:
            best_loss = final_loss
            best_lr = lr
            best_state = state
    
    convergence_steps = next((i for i, l in enumerate(best_state.loss_history) if l <= best_loss*1.1), n_steps)
    
    return {
        "best_lr": best_lr,
        "best_loss": best_loss,
        "convergence_steps": convergence_steps,
        "all_results": all_results
    }


def run_lr_convergence_analysis(surface, SGD_class, Adam_class, lr_range, x_init, y_init):
    """Analyze learning rate vs convergence speed"""
    conv_sgd = []
    conv_adam = []
    
    for lr in lr_range:
        
        sgd_opt = SGD_class(lr)
        state_sgd = sgd_opt.init_state(np.array([x_init, y_init]))
        for step in range(100):
            x, y = state_sgd.params
            loss = surface.compute(np.array([x]), np.array([y]))[0]
            grad_x, grad_y = surface.gradient(x, y)
            sgd_opt.step(state_sgd, (grad_x, grad_y), loss)
        conv_sgd.append(next((i for i, l in enumerate(state_sgd.loss_history) if l <= min(state_sgd.loss_history)*1.1), 100))
        
        
        adam_opt = Adam_class(lr)
        state_adam = adam_opt.init_state(np.array([x_init, y_init]))
        for step in range(100):
            x, y = state_adam.params
            loss = surface.compute(np.array([x]), np.array([y]))[0]
            grad_x, grad_y = surface.gradient(x, y)
            adam_opt.step(state_adam, (grad_x, grad_y), loss)
        conv_adam.append(next((i for i, l in enumerate(state_adam.loss_history) if l <= min(state_adam.loss_history)*1.1), 100))
    
    return conv_sgd, conv_adam




def test_divergence(surface, optimizer, x_init, y_init, max_steps=200):
    """Test if optimizer diverges with given learning rate"""
    state = optimizer.init_state(np.array([x_init, y_init]))
    
    for step in range(max_steps):
        x, y = state.params
        
        # Check for divergence
        if np.isnan(x) or np.isnan(y) or np.abs(x) > 1e6 or np.abs(y) > 1e6:
            return True, step, state
        
        loss = surface.compute(np.array([x]), np.array([y]))[0]
        grad_x, grad_y = surface.gradient(x, y)
        optimizer.step(state, (grad_x, grad_y), loss)
    
    return False, max_steps, state


def plot_stability_test(state):
    """Plot stability test results"""
    fig, ax = plt.subplots(figsize=(10, 5))
    ax.plot(state.loss_history, linewidth=2)
    ax.set_xlabel("Step")
    ax.set_ylabel("Loss")
    ax.set_title("Stability Test")
    ax.grid(True, alpha=0.3)
    st.pyplot(fig)
    plt.close()




def test_custom_function(custom_surface, x_init, y_init, optimizer_class, lr, n_steps=100):
    """Test optimizer on custom loss function"""
    opt = optimizer_class(lr)
    state = opt.init_state(np.array([x_init, y_init]))
    
    for step in range(n_steps):
        x, y = state.params
        loss = custom_surface.compute(np.array([x]), np.array([y]))[0]
        grad_x, grad_y = custom_surface.gradient(x, y)
        opt.step(state, (grad_x, grad_y), loss)
    
    return state


def plot_custom_optimization(custom_surface, state, bounds):
    """Plot optimization on custom surface"""
    fig, axes = plt.subplots(1, 2, figsize=(12, 5))
    
    # Contour
    x_range = np.linspace(bounds[0], bounds[1], 100)
    y_range = np.linspace(bounds[0], bounds[1], 100)
    X, Y = np.meshgrid(x_range, y_range)
    Z = custom_surface.compute(X, Y)
    
    axes[0].contour(X, Y, Z, levels=20, cmap='viridis')
    traj = np.array(state.trajectory)
    axes[0].plot(traj[:, 0], traj[:, 1], 'ro-', linewidth=2, markersize=4)
    axes[0].set_xlabel("X")
    axes[0].set_ylabel("Y")
    axes[0].set_title("Optimization Trajectory")
    axes[0].grid(True, alpha=0.3)
    
    # Loss
    axes[1].plot(state.loss_history, linewidth=2)
    axes[1].set_xlabel("Step")
    axes[1].set_ylabel("Loss")
    axes[1].set_title("Convergence")
    axes[1].set_yscale('log')
    axes[1].grid(True, alpha=0.3)
    
    plt.tight_layout()
    st.pyplot(fig)
    plt.close()