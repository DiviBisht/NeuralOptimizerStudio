import streamlit as st
import numpy as np
import pandas as pd
from dataset_explorer import render_dataset_explorer

from loss_surface  import get_all_surfaces, CustomFunctionSurface
from optimizers    import (SGD, Momentum, Nesterov, AdaGrad, RMSProp, Adam,
                           AdamW, RAdam, LAMB, Lookahead, LBFGS, Newton,
                           RandomSearch, get_learning_rate)
from visualization import (plot_3d_surface, plot_contour_with_trajectories,
                            plot_convergence_analysis, create_metrics_table,
                            plot_exploration_exploitation, plot_exploration_heatmap,
                            display_winners, plot_grid_search_results,
                            plot_lr_vs_convergence, plot_batch_distributions,
                            display_step_metrics, display_optimizer_math,
                            plot_realtime_gradient, plot_stability_test)
from application   import (train_mnist_model, plot_training_history,
                            plot_weight_distributions, display_training_metrics,
                            run_batch_experiment, display_batch_statistics,
                            determine_batch_winner, run_grid_search,
                            run_lr_convergence_analysis, test_divergence,
                            test_custom_function, plot_custom_optimization)

# ─────────────────────────────────────────────────────────────────────────────
# PAGE CONFIG + GLOBAL CSS
# ─────────────────────────────────────────────────────────────────────────────
st.set_page_config(
    page_title='Neural Optimizer Studio',
    page_icon='🧠',
    layout='wide',
    initial_sidebar_state='collapsed',
)

st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');

/* ── base ── */
html, body, [class*="css"] { font-family: 'Inter', sans-serif; }
.stApp { background: #0a0e1a; color: #e2e8f0; }

/* ── hide default header / footer ── */
#MainMenu, footer, header { visibility: hidden; }

/* ── hero banner ── */
.hero {
    background: linear-gradient(135deg, #1a1040 0%, #0f1e3d 50%, #0a0e1a 100%);
    border: 1px solid rgba(108,99,255,0.3);
    border-radius: 16px;
    padding: 2.2rem 2.8rem 1.8rem;
    margin-bottom: 1.6rem;
    position: relative; overflow: hidden;
}
.hero::before {
    content:''; position:absolute; top:-60px; right:-60px;
    width:260px; height:260px;
    background: radial-gradient(circle, rgba(108,99,255,0.18) 0%, transparent 70%);
    border-radius:50%;
}
.hero h1 { font-size:2.4rem; font-weight:700; color:#fff;
           background: linear-gradient(90deg,#a78bfa,#60a5fa,#34d399);
           -webkit-background-clip:text; -webkit-text-fill-color:transparent;
           margin:0 0 .4rem; }
.hero p  { color:#94a3b8; font-size:1.05rem; margin:0; }

/* ── section card ── */
.card {
    background: #111827;
    border: 1px solid rgba(255,255,255,0.07);
    border-radius: 12px;
    padding: 1.4rem 1.6rem;
    margin-bottom: 1rem;
}
.card h3 { color:#e2e8f0; font-size:1rem; font-weight:600; margin:0 0 .8rem; }

/* ── nav tabs ── */
.stTabs [data-baseweb="tab-list"] {
    background: #111827;
    border-radius: 10px;
    padding: 4px;
    gap: 2px;
    border: 1px solid rgba(255,255,255,0.08);
}
.stTabs [data-baseweb="tab"] {
    border-radius: 8px;
    color: #94a3b8;
    font-weight: 500;
    font-size: .9rem;
    padding: .45rem 1rem;
    transition: all .2s;
}
.stTabs [aria-selected="true"] {
    background: linear-gradient(135deg,#6C63FF,#4f46e5) !important;
    color: #fff !important;
    font-weight: 600;
}

/* ── inner viz tabs ── */
div[data-testid="stVerticalBlock"] .stTabs [aria-selected="true"] {
    background: rgba(108,99,255,0.25) !important;
    color: #a78bfa !important;
}

/* ── sliders ── */
/* thumb handle */
.stSlider [data-baseweb="slider"] [role="slider"] {
    background: #6C63FF !important;
    border-color: #6C63FF !important;
}
/* filled track */
.stSlider [data-baseweb="slider"] [data-testid="stSlider"] div[class*="Track"] > div:first-child {
    background: #6C63FF !important;
}
/* tick labels */
.stSlider [data-testid="stTickBarMax"],
.stSlider [data-testid="stTickBarMin"] { color:#64748b; font-size:.78rem; }
/* value tooltip */
.stSlider [data-baseweb="tooltip"] { background:#1a2235; border:1px solid rgba(108,99,255,.4); border-radius:6px; }

/* ── select boxes ── */
.stSelectbox [data-baseweb="select"] > div {
    background: #1a2235;
    border: 1px solid rgba(255,255,255,0.10);
    border-radius: 8px;
    color: #e2e8f0;
}
.stMultiSelect [data-baseweb="select"] > div {
    background: #1a2235;
    border: 1px solid rgba(255,255,255,0.10);
    border-radius: 8px;
}

/* ── primary button ── */
.stButton>button[kind="primary"] {
    background: linear-gradient(135deg,#6C63FF,#4f46e5);
    border: none; border-radius: 8px;
    color: #fff; font-weight: 600; font-size: .95rem;
    padding: .55rem 1.6rem;
    transition: transform .15s, box-shadow .15s;
}
.stButton>button[kind="primary"]:hover {
    transform: translateY(-1px);
    box-shadow: 0 6px 20px rgba(108,99,255,.45);
}
.stButton>button {
    background: #1a2235;
    border: 1px solid rgba(255,255,255,0.10);
    border-radius: 8px; color: #e2e8f0;
}

/* ── metrics ── */
[data-testid="stMetric"] {
    background: #1a2235;
    border: 1px solid rgba(255,255,255,0.07);
    border-radius: 10px;
    padding: .7rem 1rem;
}
[data-testid="stMetricLabel"]  { color:#94a3b8; font-size:.82rem; }
[data-testid="stMetricValue"]  { color:#e2e8f0; font-size:1.35rem; font-weight:700; }
[data-testid="stMetricDelta"]  { color:#6C63FF; }

/* ── dataframe ── */
.stDataFrame { border-radius:10px; overflow:hidden;
               border:1px solid rgba(255,255,255,0.08); }
[data-testid="stDataFrameResizable"] th {
    background:#1a2235 !important; color:#94a3b8 !important; }
[data-testid="stDataFrameResizable"] td { color:#e2e8f0 !important; }

/* ── text inputs / areas ── */
.stTextArea textarea, .stTextInput input {
    background:#1a2235; border:1px solid rgba(255,255,255,0.10);
    border-radius:8px; color:#e2e8f0;
}
.stNumberInput input {
    background:#1a2235; border:1px solid rgba(255,255,255,0.10);
    border-radius:8px; color:#e2e8f0;
}

/* ── info / success / error / warning ── */
.stAlert { border-radius:10px !important; }

/* ── spinner ── */
.stSpinner { color:#6C63FF !important; }

/* ── section divider ── */
.section-title {
    font-size:1.05rem; font-weight:600; color:#a78bfa;
    letter-spacing:.04em; text-transform:uppercase;
    border-bottom:1px solid rgba(167,139,250,.25);
    padding-bottom:.4rem; margin:.6rem 0 .9rem;
}

/* ── badge ── */
.badge {
    display:inline-block;
    background:rgba(108,99,255,.18);
    border:1px solid rgba(108,99,255,.4);
    border-radius:20px;
    padding:.2rem .65rem;
    font-size:.78rem; font-weight:500; color:#a78bfa;
    margin:.2rem .15rem;
}
</style>
""", unsafe_allow_html=True)

# ─────────────────────────────────────────────────────────────────────────────
# HERO BANNER
# ─────────────────────────────────────────────────────────────────────────────
st.markdown("""
<div class="hero">
  <h1>🧠 Neural Optimizer Studio</h1>
  <p>Visualise, compare and analyse gradient-based optimisers on real loss surfaces — 
     animated 3-D trajectories, real-time gradient fields, MNIST training & more.</p>
  <div style="margin-top:.8rem;">
    <span class="badge">SGD</span><span class="badge">Momentum</span>
    <span class="badge">Adam</span><span class="badge">AdamW</span>
    <span class="badge">RAdam</span><span class="badge">LAMB</span>
    <span class="badge">L-BFGS</span><span class="badge">Nesterov</span>
  </div>
</div>
""", unsafe_allow_html=True)

# ─────────────────────────────────────────────────────────────────────────────
# MAIN TABS
# ─────────────────────────────────────────────────────────────────────────────
main_tabs = st.tabs([
    '🎯 Optimizer Comparison',
    '📊 Hyperparameter Tuning',
    '🧠 MNIST Training',
    '📚 Educational Mode',
    '🔬 Batch Experiments',
    '⚙️ Custom Loss Designer',
    "📂 Dataset Explorer"
])

# ═══════════════════════════════════════════════════════════════════════════════
# TAB 1 — MAIN OPTIMIZER COMPARISON
# ═══════════════════════════════════════════════════════════════════════════════
with main_tabs[0]:
    left, right = st.columns([1, 2.4], gap='large')

    with left:
        st.markdown('<div class="section-title">Surface & Start</div>', unsafe_allow_html=True)
        surfaces         = get_all_surfaces()
        selected_surface = st.selectbox('Loss Surface', list(surfaces.keys()), key='surf_main')
        surface          = surfaces[selected_surface]

        # Known minima reference table
        KNOWN_MINIMA = {
            'Quadratic Bowl':  ('(0, 0)',      '0.0',   'Easy — all optimizers should converge'),
            'Ellipsoid Bowl':  ('(0, 0)',      '0.0',   'Elongated — tests momentum dampening'),
            'Rosenbrock':      ('(1, 1)',      '0.0',   'Hard — use Adam, LR≈0.01, 300+ steps'),
            'Rastrigin':       ('(0, 0)',      '0.0',   'Many local minima — may get trapped'),
            'Beale':           ('(3, 0.5)',    '0.0',   'Hard — use Adam/Momentum, LR≈0.01'),
            'Ackley Function': ('(0, 0)',      '0.0',   'Tricky walls — use Adam, LR≈0.01'),
            'Noisy Quadratic': ('≈(0, 0)',     '≈0.0',  'Noisy gradients — Momentum helps'),
            'MNIST Loss':      ('varies',      'varies','Real NN loss — no exact minimum'),
        }
        if selected_surface in KNOWN_MINIMA:
            km = KNOWN_MINIMA[selected_surface]
            st.markdown(
                f'<div style="background:rgba(108,99,255,0.10);border:1px solid rgba(108,99,255,0.3);'
                f'border-radius:8px;padding:.6rem .9rem;margin:.4rem 0 .6rem;font-size:.82rem;">'
                f'<span style="color:#a78bfa;font-weight:600;">🎯 Known Minimum:</span> '
                f'<span style="color:#e2e8f0;">{km[0]}</span> &nbsp;·&nbsp; '
                f'<span style="color:#4ECDC4;">loss = {km[1]}</span> &nbsp;·&nbsp; '
                f'<span style="color:#64748b;">{km[2]}</span>'
                f'</div>', unsafe_allow_html=True
            )

        # default start = 60% of upper bound, clamped inside surface bounds
        _lo, _hi  = float(surface.bounds[0]), float(surface.bounds[1])
        _def      = round(min(max(_hi * 0.6, _lo + 0.1), _hi - 0.1), 1)
        c1, c2 = st.columns(2)
        with c1: x_init = st.slider('Start X', _lo, _hi, _def, 0.1, key='x_main')
        with c2: y_init = st.slider('Start Y', _lo, _hi, _def, 0.1, key='y_main')

        st.markdown('<div class="section-title">Training</div>', unsafe_allow_html=True)
        n_steps     = st.slider('Steps',         10, 500, 200, 10)
        noise_level = st.slider('Gradient Noise', 0.0, 0.5, 0.0, 0.01)
        lr_schedule = st.selectbox('LR Schedule',
            ['constant','linear_decay','exponential','cosine_annealing','step_decay','warmup'])

        st.markdown('<div class="section-title">Optimizers</div>', unsafe_allow_html=True)
        ALL_OPTS = ['SGD','Momentum','Adam','AdamW','RAdam','LAMB','Nesterov','L-BFGS','Newton']
        opt_select = st.multiselect('Choose Optimizers', ALL_OPTS,
                                    default=['SGD','Momentum','Adam'])

        OPT_DEFAULTS = {
            'SGD':0.01,'Momentum':0.01,'Adam':0.01,'AdamW':0.01,
            'RAdam':0.01,'LAMB':0.005,'Nesterov':0.01,'L-BFGS':0.05,'Newton':0.05
        }
        LR_RANGES = {
            'SGD':(0.001,0.5),'Momentum':(0.001,0.5),'Adam':(0.0001,0.1),
            'AdamW':(0.0001,0.1),'RAdam':(0.0001,0.1),'LAMB':(0.0001,0.05),
            'Nesterov':(0.001,0.5),'L-BFGS':(0.001,0.5),'Newton':(0.001,0.5)
        }

        opt_configs = {}
        def _make_opt(name, lr):
            """Separate function avoids Python lambda closure bug."""
            if name == 'SGD':      return SGD(lr)
            if name == 'Momentum': return Momentum(lr, 0.9)
            if name == 'Adam':     return Adam(lr)
            if name == 'AdamW':    return AdamW(lr)
            if name == 'RAdam':    return RAdam(lr)
            if name == 'LAMB':     return LAMB(lr)
            if name == 'Nesterov': return Nesterov(lr, 0.9)
            if name == 'L-BFGS':   return LBFGS(lr)
            if name == 'Newton':   return Newton(lr)

        for opt in opt_select:
            lo, hi = LR_RANGES[opt]
            lr = st.slider(f'{opt} LR', lo, hi, OPT_DEFAULTS[opt], lo, key=f'lr_{opt}')
            opt_configs[opt] = _make_opt(opt, lr)

        run_btn = st.button('🚀 Run Optimization', type='primary', use_container_width=True)

    with right:
        # ── run ──────────────────────────────────────────────────────────────
        # Only run when button explicitly pressed — never auto-trigger on reload
        if run_btn and len(opt_configs) > 0:
            with st.spinner('⚙️ Running optimizers…'):
                x_range = np.linspace(surface.bounds[0], surface.bounds[1], 100)
                y_range = np.linspace(surface.bounds[0], surface.bounds[1], 100)
                X, Y    = np.meshgrid(x_range, y_range)
                Z       = surface.compute(X, Y)

                init_params = np.array([x_init, y_init])
                results     = {}
                for name, opt in opt_configs.items():
                    state   = opt.init_state(init_params.copy())
                    base_lr = opt.learning_rate  # snapshot BEFORE loop (fixes mutation bug)
                    for step in range(n_steps):
                        x, y = state.params
                        # gradient clipping — prevents exploding gradients on steep surfaces
                        loss  = surface.compute(np.array([x]), np.array([y]))[0]
                        gx, gy = surface.gradient(x, y)
                        grad_norm = np.sqrt(gx**2 + gy**2) + 1e-8
                        clip = 10.0
                        if grad_norm > clip:
                            gx, gy = gx/grad_norm*clip, gy/grad_norm*clip
                        if noise_level > 0:
                            gx += np.random.randn() * noise_level
                            gy += np.random.randn() * noise_level
                        # apply LR schedule using snapshotted base_lr
                        if hasattr(opt, 'learning_rate'):
                            opt.learning_rate = get_learning_rate(base_lr, lr_schedule, step, n_steps)
                        opt.step(state, (gx, gy), loss)
                    results[name] = state

                st.session_state.update(results=results, X=X, Y=Y, Z=Z,
                                        surface=surface, surface_name=selected_surface)

        if 'results' not in st.session_state or not st.session_state.results:
            st.markdown("""
            <div style="text-align:center;padding:5rem 2rem;">
              <div style="font-size:4rem;margin-bottom:1.2rem;">⚡</div>
              <div style="font-size:1.2rem;font-weight:600;color:#e2e8f0;margin-bottom:.5rem;">
                  Ready to Optimise
              </div>
              <div style="font-size:.95rem;color:#64748b;">
                  Select optimizers on the left, configure your parameters,<br>
                  then click <b style="color:#a78bfa;">Run Optimization</b> to begin.
              </div>
            </div>""", unsafe_allow_html=True)
        else:
            R  = st.session_state.results
            X  = st.session_state.X
            Y  = st.session_state.Y
            Z  = st.session_state.Z
            # safe surface resolution — never crashes on page reload
            sn = st.session_state.get('surface_name', selected_surface)
            sf = get_all_surfaces().get(sn, surface)
            # warn if user changed surface/optimizers without re-running
            if sn != selected_surface:
                st.warning(f'⚠️ Showing results for **{sn}**. '
                           f'Click **Run Optimization** to update for **{selected_surface}**.')

            # winner summary bar
            best = min(R.items(), key=lambda x: min(x[1].loss_history))
            worst = max(R.items(), key=lambda x: min(x[1].loss_history))
            m1, m2, m3, m4 = st.columns(4)
            with m1: st.metric('🏆 Best Optimizer',    best[0])
            with m2: st.metric('📉 Best Loss',         f'{min(best[1].loss_history):.5f}')
            with m3: st.metric('📊 Optimizers Run',    len(R))
            with m4: st.metric('🔢 Steps',             len(best[1].loss_history))
            st.markdown('<div style="margin-bottom:.8rem;"></div>', unsafe_allow_html=True)

            viz_tabs = st.tabs([
                '🗺️ 3D Surface',
                '🎯 Contour Plot',
                '🔴 Real-Time Gradient',
                '📈 Convergence',
                '📋 Metrics',
                '🔍 Exploration',
            ])

            with viz_tabs[0]:
                st.markdown(
                    '<div style="background:rgba(108,99,255,0.08);border:1px solid '
                    'rgba(108,99,255,0.25);border-radius:10px;padding:.7rem 1.1rem;'
                    'margin-bottom:.8rem;font-size:.9rem;color:#a78bfa;">'
                    '🎬 &nbsp;<b>Real-time 3D animation</b> — configure speed & camera below, '
                    'then press <b>▶ Play Animation</b>. '
                    'Balls roll live down the loss surface step-by-step.</div>',
                    unsafe_allow_html=True
                )
                plot_3d_surface(X, Y, Z, R, sn)

            with viz_tabs[1]:
                plot_contour_with_trajectories(X, Y, Z, R, sf, sn)

            with viz_tabs[2]:
                st.markdown(
                    '> Press **▶ Play** inside the chart to animate all optimizers simultaneously. '
                    'Drag the slider to scrub frame-by-frame. '
                    'Large coloured arrows = live descent direction at each step.')
                plot_realtime_gradient(X, Y, Z, R, sf, sn)

            with viz_tabs[3]:
                plot_convergence_analysis(R)

            with viz_tabs[4]:
                df = create_metrics_table(R, n_steps)
                st.dataframe(df, use_container_width=True, hide_index=True)
                st.divider()
                display_winners(R)

            with viz_tabs[5]:
                plot_exploration_exploitation(R)
                plot_exploration_heatmap(R)


# ═══════════════════════════════════════════════════════════════════════════════
# TAB 2 — HYPERPARAMETER TUNING
# ═══════════════════════════════════════════════════════════════════════════════
with main_tabs[1]:
    st.markdown('<div class="section-title">Grid Search — Auto-Suggest Learning Rates</div>',
                unsafe_allow_html=True)

    col1, col2, col3 = st.columns(3)
    with col1:
        surfaces_tune    = get_all_surfaces()
        surf_name_tune   = st.selectbox('Loss Surface', list(surfaces_tune.keys()), key='surf_tune')
        surface_tune     = surfaces_tune[surf_name_tune]
    with col2:
        x_init_tune = st.slider('Start X', -5.0, 5.0, 2.0, 0.1, key='x_tune')
        y_init_tune = st.slider('Start Y', -5.0, 5.0, 2.0, 0.1, key='y_tune')
    with col3:
        n_steps_tune  = st.slider('Steps', 10, 200, 50, 10, key='steps_tune')
        n_lr_tune     = st.slider('# LR candidates', 3, 10, 5, 1)

    if st.button('🔍 Run Grid Search', type='primary', key='grid_btn'):
        lr_range_tune = np.logspace(-4, -1, n_lr_tune)
        grid_results  = {}
        progress      = st.progress(0)

        for i, (opt_name, opt_cls) in enumerate([('SGD', SGD), ('Adam', Adam)]):
            result = run_grid_search(surface_tune, opt_cls, lr_range_tune,
                                     x_init_tune, y_init_tune, n_steps_tune)
            grid_results[opt_name] = result
            progress.progress((i+1)/2)

        df = pd.DataFrame([{
            'Optimizer': o,
            'Recommended LR': f"{r['best_lr']:.6f}",
            'Best Loss':       f"{r['best_loss']:.6f}",
            'Convergence Steps': r['convergence_steps'],
        } for o, r in grid_results.items()])
        st.dataframe(df, use_container_width=True, hide_index=True)

        plot_data = {o: r['all_results'] for o, r in grid_results.items()}
        plot_grid_search_results(plot_data)

    st.divider()
    st.markdown('<div class="section-title">LR vs Convergence Speed</div>',
                unsafe_allow_html=True)
    lr_range_cv = np.logspace(-4, -1, 8)
    conv_sgd, conv_adam = run_lr_convergence_analysis(
        surface_tune, SGD, Adam, lr_range_cv, x_init_tune, y_init_tune)
    plot_lr_vs_convergence(lr_range_cv, conv_sgd, conv_adam)

    st.divider()
    st.markdown('<div class="section-title">⚠️ Divergence Detection</div>',
                unsafe_allow_html=True)
    if st.checkbox('Test for Divergence'):
        lr_test = st.slider('Test Learning Rate', 0.0001, 1.0, 0.1, 0.001, key='lr_div')
        diverged, step_div, state_div = test_divergence(
            surface_tune, Adam(lr_test), x_init_tune, y_init_tune)
        if diverged:
            st.error(f'⚠️ DIVERGENCE at step {step_div} with LR={lr_test}')
        else:
            st.success(f'✅ Stable — no divergence with LR={lr_test}')
            plot_stability_test(state_div)


# ═══════════════════════════════════════════════════════════════════════════════
# TAB 3 — MNIST TRAINING
# ═══════════════════════════════════════════════════════════════════════════════
with main_tabs[2]:
    st.markdown("""
    <div class="card">
      <h3>🧠 Train a real neural network on MNIST with your chosen optimizer</h3>
      <p style="color:#94a3b8;margin:0;font-size:.9rem;">
        Uses 5 000 training samples for speed. Tracks train/val loss and accuracy per epoch.
      </p>
    </div>""", unsafe_allow_html=True)

    left_mn, right_mn = st.columns([1, 2], gap='large')
    with left_mn:
        st.markdown('<div class="section-title">Configuration</div>', unsafe_allow_html=True)
        epochs      = st.slider('Epochs',       1, 10, 3)
        batch_size  = st.selectbox('Batch Size', [32, 64, 128, 256])
        opt_choice  = st.selectbox('Optimizer',  ['SGD','Momentum','Adam','AdamW','RAdam'])
        lr_mnist    = st.slider('Learning Rate', 0.0001, 0.1, 0.001, 0.0001, format='%.4f')
        train_btn   = st.button('🚀 Train Model', type='primary', use_container_width=True)

    with right_mn:
        if train_btn:
            with st.spinner('🏋️ Training on MNIST…'):
                history, test_loss, test_acc, model = train_mnist_model(
                    epochs, batch_size, opt_choice, lr_mnist)
            display_training_metrics(history, test_acc)
            plot_training_history(history)
            plot_weight_distributions(model)
        else:
            st.markdown("""
            <div style="text-align:center;padding:3rem;color:#475569;">
              <div style="font-size:3rem;margin-bottom:.8rem;">🏋️</div>
              <div style="color:#94a3b8;">Configure and click <b>Train Model</b></div>
            </div>""", unsafe_allow_html=True)


# ═══════════════════════════════════════════════════════════════════════════════
# TAB 4 — EDUCATIONAL MODE
# ═══════════════════════════════════════════════════════════════════════════════
with main_tabs[3]:
    st.markdown("""
    <div class="card">
      <h3>📚 Step-by-Step Optimizer Walkthrough</h3>
      <p style="color:#94a3b8;margin:0;font-size:.9rem;">
        Move the slider to step through the optimization process one iteration at a time
        and see the maths update live.
      </p>
    </div>""", unsafe_allow_html=True)

    edu_left, edu_right = st.columns([1, 2], gap='large')
    with edu_left:
        st.markdown('<div class="section-title">Setup</div>', unsafe_allow_html=True)
        surfaces_edu  = get_all_surfaces()
        edu_surf_name = st.selectbox('Surface', ['Quadratic Bowl','Rosenbrock','Ackley'], key='edu_surf')
        surface_edu   = surfaces_edu[edu_surf_name]
        x_edu = st.slider('Start X', -5.0, 5.0, 2.0, 0.1, key='edu_x')
        y_edu = st.slider('Start Y', -5.0, 5.0, 2.0, 0.1, key='edu_y')
        edu_opt = st.selectbox('Optimizer', ['SGD','Momentum','Adam'], key='edu_opt')
        if edu_opt == 'SGD':
            edu_lr = st.slider('LR', 0.001, 0.1, 0.01, 0.001, key='edu_lr_sgd')
            opt_edu = SGD(edu_lr)
        elif edu_opt == 'Momentum':
            edu_lr = st.slider('LR', 0.001, 0.1, 0.01, 0.001, key='edu_lr_mom')
            opt_edu = Momentum(edu_lr, 0.9)
        else:
            edu_lr = st.slider('LR', 0.0001, 0.01, 0.001, 0.0001, key='edu_lr_adam')
            opt_edu = Adam(edu_lr)

        step_num = st.slider('Step Number', 0, 50, 0, 1, key='edu_step')

    with edu_right:
        state_edu = opt_edu.init_state(np.array([x_edu, y_edu]))
        for _ in range(step_num):
            x_, y_ = state_edu.params
            l_ = surface_edu.compute(np.array([x_]), np.array([y_]))[0]
            gx_, gy_ = surface_edu.gradient(x_, y_)
            opt_edu.step(state_edu, (gx_, gy_), l_)

        st.markdown('<div class="section-title">Current State</div>', unsafe_allow_html=True)
        display_step_metrics(state_edu, surface_edu)
        st.divider()
        display_optimizer_math(edu_opt, edu_lr, state_edu)

        st.divider()
        st.markdown('<div class="section-title">🎓 Quick Quiz</div>', unsafe_allow_html=True)
        quiz = st.radio(
            'Which optimizer uses both first AND second moment estimates?',
            ['SGD', 'Momentum', 'Adam', 'Nesterov'], horizontal=True, key='quiz1')
        if quiz == 'Adam':
            st.success('✅ Correct! Adam maintains m̂ (1st moment) and v̂ (2nd moment).')
        elif quiz:
            st.error('❌ Not quite — think about adaptive learning rates.')

        quiz2 = st.radio(
            'What does a larger momentum coefficient (β → 1) do?',
            ['Makes learning slower', 'Smooths out oscillations', 'Increases gradient noise',
             'Resets the optimizer'], horizontal=True, key='quiz2')
        if quiz2 == 'Smooths out oscillations':
            st.success('✅ Correct! High β averages more past gradients, reducing oscillation.')
        elif quiz2:
            st.error('❌ Higher β accumulates more history, damping oscillations.')


# ═══════════════════════════════════════════════════════════════════════════════
# TAB 5 — BATCH EXPERIMENTS
# ═══════════════════════════════════════════════════════════════════════════════
with main_tabs[4]:
    st.markdown("""
    <div class="card">
      <h3>🔬 Statistical Batch Comparison</h3>
      <p style="color:#94a3b8;margin:0;font-size:.9rem;">
        Run many trials from random starting points and compare final-loss distributions.
      </p>
    </div>""", unsafe_allow_html=True)

    col1, col2, col3 = st.columns(3)
    surfaces_batch = get_all_surfaces()
    ALL_BATCH_OPTS = ['Adam','SGD','Momentum','AdamW','RAdam','Nesterov']
    with col1:
        batch_surf_name = st.selectbox('Loss Surface',
            ['Quadratic Bowl','Rosenbrock','Rastrigin','Beale','Ackley Function',
             'Ellipsoid Bowl','Noisy Quadratic'], key='batch_surf')
    with col2:
        batch_opt1 = st.selectbox('Optimizer A', ALL_BATCH_OPTS, index=1, key='bopt1')
    with col3:
        batch_opt2 = st.selectbox('Optimizer B', ALL_BATCH_OPTS, index=0, key='bopt2')

    num_trials = st.slider('Number of Trials', 5, 100, 20, 5)

    if st.button('▶️ Run Batch Experiments', type='primary', key='batch_btn'):
        batch_surf_obj = surfaces_batch[batch_surf_name]

        # Use good learning rates per optimizer type (templates — deepcopied per trial)
        def _mk_opt(name):
            if name == 'Adam':     return Adam(0.01)
            if name == 'Momentum': return Momentum(0.01, 0.9)
            if name == 'SGD':      return SGD(0.01)
            if name == 'AdamW':    return AdamW(0.01)
            if name == 'RAdam':    return RAdam(0.01)
            return SGD(0.01)

        o1 = _mk_opt(batch_opt1)
        o2 = _mk_opt(batch_opt2)

        with st.spinner(f'Running {num_trials} trials…'):
            r1, r2 = run_batch_experiment(batch_surf_obj, o1, o2, num_trials)

        display_batch_statistics(r1, r2, batch_opt1, batch_opt2)
        plot_batch_distributions(r1, r2, batch_opt1, batch_opt2)
        determine_batch_winner(r1, r2, batch_opt1, batch_opt2)


# ═══════════════════════════════════════════════════════════════════════════════
# TAB 6 — CUSTOM LOSS DESIGNER
# ═══════════════════════════════════════════════════════════════════════════════
with main_tabs[5]:
    st.markdown("""
    <div class="card">
      <h3>⚙️ Custom Loss Surface Designer</h3>
      <p style="color:#94a3b8;margin:0;font-size:.9rem;">
        Write any function of <code>x</code>, <code>y</code> and <code>np</code>.
        Adam will optimise it and show the trajectory.
      </p>
    </div>""", unsafe_allow_html=True)

    cl1, cl2 = st.columns([1.2, 2], gap='large')
    with cl1:
        st.markdown('<div class="section-title">Function</div>', unsafe_allow_html=True)
        st.code('# Examples\nx**2 + y**2\n(1-x)**2 + 100*(y-x**2)**2\nnp.sin(x)*np.cos(y) + 0.1*(x**2+y**2)')
        custom_func = st.text_area('f(x, y) =', value='x**2 + y**2', height=80)
        cc1, cc2 = st.columns(2)
        with cc1: custom_min = st.number_input('Bounds min', -10.0, -0.1, -5.0, 0.5)
        with cc2: custom_max = st.number_input('Bounds max',  0.1, 10.0,  5.0, 0.5)

        st.markdown('<div class="section-title">Start & Optimizer</div>', unsafe_allow_html=True)
        cx0 = st.slider('Start X', custom_min, custom_max, min(3.0, custom_max*0.6), 0.1, key='cx0')
        cy0 = st.slider('Start Y', custom_min, custom_max, min(3.0, custom_max*0.6), 0.1, key='cy0')
        custom_lr = st.slider('Adam LR', 0.001, 0.1, 0.01, 0.001)
        test_btn  = st.button('🚀 Optimize', type='primary', use_container_width=True, key='cust_btn')

    with cl2:
        try:
            cs = CustomFunctionSurface(custom_func, (custom_min, custom_max))
            tv = cs.compute(np.array([0.0]), np.array([0.0]))
            st.success(f'✅ Valid function — f(0,0) = {tv[0]:.4f}')
            if test_btn:
                with st.spinner('Optimizing…'):
                    state_c = test_custom_function(cs, cx0, cy0, Adam, custom_lr)
                plot_custom_optimization(cs, state_c, (custom_min, custom_max))
        except Exception as e:
            st.error(f'❌ Function error: {e}')
    
with main_tabs[6]:
       render_dataset_explorer()